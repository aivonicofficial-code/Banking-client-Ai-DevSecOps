# Architecture and Design Documentation

## Overview

This infrastructure provides a production-ready setup for running Bedrock agents on AWS with ECS Fargate backend and Lambda-based API integration using the Strands framework for autonomous task execution.

## Architecture Components

### 1. API Layer

**Component**: AWS API Gateway (HTTP)
- Provides REST endpoints for agent invocation
- Handles request/response transformations
- CORS support for web clients
- Automatic request validation

**Design Decision**: HTTP API Gateway chosen over REST API for:
- Lower latency and cost
- Simpler implementation for streaming responses
- Native support for $default routes

### 2. Lambda Functions

#### Agent Invoker (`lambda_agent_invoker`)
- **Purpose**: Invoke Bedrock agents with user requests
- **Runtime**: Python 3.11
- **VPC Integration**: Yes (for secure Bedrock access)
- **Key Features**:
  - Session management for multi-turn conversations
  - Configurable inference parameters
  - Stream processing for agent responses
  - Error handling and logging

#### Task Runner (`lambda_task_runner`)
- **Purpose**: Spawn ECS Fargate tasks for long-running operations
- **Runtime**: Python 3.11
- **VPC Integration**: Yes (for ECS cluster communication)
- **Key Features**:
  - Task orchestration
  - Environment variable injection
  - Task monitoring and logging
  - Asynchronous execution support

**Design Decision**: Two separate Lambda functions provide:
- Clear separation of concerns
- Independent scaling
- Focused error handling
- Better testability

### 3. Bedrock Agent

**Component**: AWS Bedrock Agent
- **Foundation Model**: Claude 3 Sonnet (customizable)
- **Session Management**: Maintains conversation context
- **Integration**: Direct invocation from Lambda

**Design Characteristics**:
- Agentic reasoning with action planning
- Automatic error recovery
- Session-based state management
- Configurable inference parameters

### 4. ECS Fargate Cluster

**Components**:
- **Cluster**: Logical grouping of services
- **Service**: Maintains desired task count with auto-scaling
- **Task Definition**: Specifies container configuration
- **Load Balancer**: Distributes traffic across tasks

**Configuration**:
- **Launch Type**: Fargate (serverless containers)
- **Network Mode**: awsvpc (modern networking)
- **CPU/Memory**: Configurable (default: 512 CPU, 1024 MB)
- **Task Count**: 2-4 (auto-scaling enabled)

**Design Decisions**:
- Fargate chosen for:
  - No infrastructure management
  - Automatic scaling
  - Better security isolation
  - Pay-per-use pricing
- Auto-scaling targets:
  - CPU: 70% target
  - Memory: 80% target

### 5. Networking

#### VPC Structure
```
VPC (10.0.0.0/16)
├── Public Subnets (Multi-AZ)
│   ├── 10.0.101.0/24 (us-east-1a)
│   └── 10.0.102.0/24 (us-east-1b)
├── Private Subnets (Multi-AZ)
│   ├── 10.0.1.0/24 (us-east-1a)
│   └── 10.0.2.0/24 (us-east-1b)
├── NAT Gateway (in public subnet)
├── Internet Gateway
└── Route Tables (public/private)
```

**Design Decisions**:
- Private subnets for ECS tasks (security)
- Public subnets for NAT Gateway
- NAT Gateway for controlled outbound access
- Multi-AZ for high availability

### 6. Security

#### IAM Roles and Policies

| Component | Role | Permissions |
|-----------|------|-------------|
| ECS Task Execution | `ecs_task_execution_role` | ECR pull, CloudWatch logs |
| ECS Task | `ecs_task_role` | Bedrock invocation, CloudWatch logs |
| Lambda | `lambda_role` | Bedrock, ECS, CloudWatch, VPC |
| Bedrock Agent | `bedrock_agent_role` | Foundation model invocation |

**Design Principle**: Least privilege access

#### Security Groups

- **ALB Security Group**: Allows HTTP/HTTPS from internet
- **ECS Security Group**: Allows container port only from ALB

### 7. Logging and Monitoring

#### CloudWatch Logs
- **ECS**: `/ecs/bedrock-agent-{env}` (7-day retention)
- **Lambda**: `/aws/lambda/bedrock-agent-{env}-*` (7-day retention)
- **API Gateway**: `/aws/apigateway/bedrock-agent-{env}` (7-day retention)

#### CloudWatch Metrics
- ECS: CPU, Memory, Task count
- Lambda: Invocations, Duration, Errors, Throttles
- API Gateway: Requests, Latency, Errors

**Design Decision**: Log retention set to 7 days for cost optimization (configurable)

## Data Flow

### Flow 1: Agent Invocation

```
Client Request
    ↓
API Gateway
    ↓
Lambda (Agent Invoker)
    ↓
Bedrock Agent
    ↓
Foundation Model (Claude)
    ↓
Agent Response
    ↓
CloudWatch Logs
    ↓
Response to Client
```

### Flow 2: ECS Task Execution

```
Client Request
    ↓
Lambda (Task Runner)
    ↓
ECS Fargate
    ↓
Container Execution
    ↓
CloudWatch Logs
    ↓
Task Status Response
```

### Flow 3: Multi-turn Conversation

```
Turn 1: User Input
    ↓ (Session ID stored)
Agent State
    ↓
Turn 2: User Input
    ↓ (Same Session ID)
Agent State (with context)
    ↓
Continue...
```

## Scaling Considerations

### Horizontal Scaling

**ECS Auto Scaling**:
- Min Tasks: 2 (for HA)
- Max Tasks: 4 (configurable)
- Scale-up: CPU > 70% or Memory > 80%
- Scale-down: CPU < 40% and Memory < 60%

**Lambda Scaling**:
- Automatic (AWS managed)
- Concurrent execution: 1000 (default)
- Reserve capacity for critical tasks

### Vertical Scaling

**ECS Task Sizing** (configurable):
- CPU: 256-4096 (256 increments)
- Memory: 512-30720 MB (depends on CPU)

**Lambda Sizing** (configurable):
- Memory: 128-10240 MB
- Timeout: 3-900 seconds

## Cost Optimization

### Strategies Implemented

1. **Fargate Spot**: Use for non-critical workloads
   ```hcl
   # Add to ecs.tf
   capacity_provider_strategy {
     capacity_provider = "FARGATE_SPOT"
     weight            = 75
   }
   ```

2. **CloudWatch Log Retention**: 7 days (configurable)

3. **Intelligent Tiering**: Monitor usage patterns

### Cost Estimation (Monthly)

| Component | Estimate | Notes |
|-----------|----------|-------|
| ECS Fargate | $20-50 | 2 tasks × 512 CPU × 1GB |
| NAT Gateway | $30 | ~45GB data transfer |
| Lambda | $5-20 | Variable based on requests |
| API Gateway | $3.50 | Per million requests |
| CloudWatch | $5-10 | Logs and metrics |
| **Total** | **$63-130** | Rough monthly estimate |

## Disaster Recovery

### Backup Strategy

1. **Infrastructure as Code**: Entire setup in Terraform
2. **State Management**: Store terraform.tfstate in S3
3. **Automated Snapshots**: CloudWatch logs retention

### Recovery Procedures

```bash
# Full infrastructure recovery
terraform init
terraform apply

# Restore from S3
aws s3 cp s3://my-backup/terraform.tfstate .
terraform apply
```

## Best Practices

### Development
1. Use separate `dev` environment for testing
2. Enable detailed logging during development
3. Use smaller task sizes to reduce costs

### Production
1. Use `prod` environment with multi-AZ
2. Enable Fargate Spot for cost savings
3. Implement CloudWatch alarms for critical metrics
4. Use AWS Secrets Manager for sensitive data
5. Enable CloudTrail for audit logging

### Security
1. Regularly rotate AWS credentials
2. Use VPC endpoints for AWS services
3. Enable VPC Flow Logs for network monitoring
4. Implement WAF rules on API Gateway
5. Regular security group audits

## Limitations and Future Enhancements

### Current Limitations

1. **Bedrock Token Limits**: Monitor usage for large responses
2. **ECS Task Size**: Limited by Fargate constraints
3. **Lambda Timeout**: 15 minutes max (for streaming use case)

### Future Enhancements

1. **Caching Layer**: Add ElastiCache for response caching
2. **Database**: DynamoDB for conversation history
3. **Batch Processing**: SQS for asynchronous job queues
4. **Advanced Monitoring**: DataDog or New Relic integration
5. **Multi-region**: Cross-region failover
6. **Custom Models**: Fine-tuned Bedrock models
7. **API Authentication**: API Key or OAuth 2.0

## References

- [AWS Bedrock Agent Architecture](https://docs.aws.amazon.com/bedrock/latest/userguide/agents.html)
- [ECS Fargate Best Practices](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task_size.html)
- [Strands Framework](https://www.anthropic.com/research/towards-general-purpose-agents)
- [AWS Lambda in VPC](https://docs.aws.amazon.com/lambda/latest/dg/vpc.html)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest)
