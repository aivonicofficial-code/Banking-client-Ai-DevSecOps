#!/bin/bash
# Deployment script for Bedrock Agent infrastructure

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}=== Bedrock Agent Deployment Script ===${NC}\n"

# Check prerequisites
echo "Checking prerequisites..."

if ! command -v terraform &> /dev/null; then
    echo -e "${RED}Terraform not found. Please install Terraform >= 1.0${NC}"
    exit 1
fi

if ! command -v aws &> /dev/null; then
    echo -e "${RED}AWS CLI not found. Please install AWS CLI v2${NC}"
    exit 1
fi

if ! command -v docker &> /dev/null; then
    echo -e "${RED}Docker not found. Please install Docker${NC}"
    exit 1
fi

echo -e "${GREEN}✓ All prerequisites installed${NC}\n"

# Get AWS account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
AWS_REGION=${AWS_REGION:-us-east-1}
PROJECT_NAME=${PROJECT_NAME:-bedrock-agent}
ENVIRONMENT=${ENVIRONMENT:-dev}
ECR_REPOSITORY="$PROJECT_NAME"

echo "AWS Account ID: $ACCOUNT_ID"
echo "AWS Region: $AWS_REGION"
echo "Project Name: $PROJECT_NAME"
echo "Environment: $ENVIRONMENT"
echo ""

# Step 1: Build and push Docker image
echo -e "${YELLOW}Step 1: Building and pushing Docker image${NC}"

# Create ECR repository if it doesn't exist
if ! aws ecr describe-repositories --repository-names $ECR_REPOSITORY --region $AWS_REGION 2>/dev/null | grep -q $ECR_REPOSITORY; then
    echo "Creating ECR repository: $ECR_REPOSITORY"
    aws ecr create-repository \
        --repository-name $ECR_REPOSITORY \
        --region $AWS_REGION \
        --tags Key=Project,Value=$PROJECT_NAME
fi

# Login to ECR
echo "Logging in to ECR..."
aws ecr get-login-password --region $AWS_REGION | \
    docker login --username AWS --password-stdin $ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com

# Build image
echo "Building Docker image..."
docker build -t $ECR_REPOSITORY:latest .

# Push image
ECR_URI="$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPOSITORY:latest"
echo "Pushing image to $ECR_URI..."
docker tag $ECR_REPOSITORY:latest $ECR_URI
docker push $ECR_URI

echo -e "${GREEN}✓ Docker image built and pushed${NC}\n"

# Step 2: Package Lambda functions
echo -e "${YELLOW}Step 2: Packaging Lambda functions${NC}"

# Package agent invoker
mkdir -p lambda_agent_invoker
cp lambda_agent_invoker.py lambda_agent_invoker/index.py
cd lambda_agent_invoker
zip -r ../lambda_agent_invoker.zip . > /dev/null 2>&1
cd ..
rm -rf lambda_agent_invoker

# Package task runner
mkdir -p lambda_task_runner
cp lambda_task_runner.py lambda_task_runner/index.py
cd lambda_task_runner
zip -r ../lambda_task_runner.zip . > /dev/null 2>&1
cd ..
rm -rf lambda_task_runner

echo -e "${GREEN}✓ Lambda functions packaged${NC}\n"

# Step 3: Update terraform.tfvars
echo -e "${YELLOW}Step 3: Updating terraform.tfvars${NC}"

# Create/update terraform.tfvars with ECR URI
cat > terraform.tfvars << EOF
aws_region        = "$AWS_REGION"
project_name      = "$PROJECT_NAME"
environment       = "$ENVIRONMENT"

# ECR Image URI
container_image_uri = "$ECR_URI"

# Bedrock configuration
bedrock_agent_name              = "strands-agent"
bedrock_foundational_model      = "anthropic.claude-3-sonnet-20240229-v1:0"

# Resource sizing
container_cpu     = 512
container_memory  = 1024
ecs_desired_count = 2

# Networking
vpc_cidr              = "10.0.0.0/16"
public_subnet_cidrs   = ["10.0.101.0/24", "10.0.102.0/24"]
private_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
enable_nat_gateway    = true

# Lambda
lambda_timeout = 300
lambda_memory  = 512
EOF

echo -e "${GREEN}✓ terraform.tfvars updated${NC}\n"

# Step 4: Terraform operations
echo -e "${YELLOW}Step 4: Running Terraform${NC}"

# Initialize
echo "Initializing Terraform..."
terraform init

# Validate
echo "Validating configuration..."
terraform validate

# Plan
echo "Creating Terraform plan..."
terraform plan -out=tfplan

# Ask for confirmation
echo ""
read -p "Do you want to apply this plan? (yes/no): " -r REPLY
if [[ ! $REPLY =~ ^[Yy][Ee][Ss]$ ]]; then
    echo "Deployment cancelled"
    exit 1
fi

# Apply
echo "Applying Terraform configuration..."
terraform apply tfplan
rm tfplan

echo -e "${GREEN}✓ Infrastructure deployed${NC}\n"

# Step 5: Display outputs
echo -e "${YELLOW}Step 5: Deployment Summary${NC}"
echo ""
echo "Deployment completed successfully!"
echo ""
echo "Outputs:"
terraform output

echo ""
echo -e "${GREEN}=== Deployment Complete ===${NC}"
echo ""
echo "Next steps:"
echo "1. Monitor ECS service: aws ecs describe-services --cluster $(terraform output -raw ecs_cluster_name) --services $(terraform output -raw ecs_service_name)"
echo "2. Test API: curl $(terraform output -raw api_gateway_endpoint)/invoke-agent"
echo "3. View logs: aws logs tail /ecs/$(terraform output -raw ecs_cluster_name) --follow"
