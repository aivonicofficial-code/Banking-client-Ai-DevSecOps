# CloudWatch Log Group for Lambda
resource "aws_cloudwatch_log_group" "lambda" {
  name              = "/aws/lambda/${local.service_name}"
  retention_in_days = 7

  tags = {
    Name = "${local.service_name}-lambda-logs"
  }
}

# Lambda Function - Agent Invoker
resource "aws_lambda_function" "agent_invoker" {
  filename      = "lambda_agent_invoker.zip"
  function_name = "${local.service_name}-agent-invoker"
  role          = aws_iam_role.lambda_role.arn
  handler       = "index.lambda_handler"
  runtime       = "python3.11"
  timeout       = var.lambda_timeout
  memory_size   = var.lambda_memory

  vpc_config {
    subnet_ids         = aws_subnet.private[*].id
    security_group_ids = [aws_security_group.ecs.id]
  }

  environment {
    variables = {
      BEDROCK_AGENT_ID = aws_bedrockagent_agent.main.agent_id
      AWS_REGION       = var.aws_region
      ECS_CLUSTER      = aws_ecs_cluster.main.name
      ECS_TASK_DEFINITION = aws_ecs_task_definition.main.family
    }
  }

  depends_on = [
    aws_iam_role_policy.lambda_bedrock_policy,
    aws_iam_role_policy.lambda_ecs_policy
  ]

  tags = {
    Name = "${local.service_name}-agent-invoker"
  }
}

# Lambda Function - Task Runner
resource "aws_lambda_function" "task_runner" {
  filename      = "lambda_task_runner.zip"
  function_name = "${local.service_name}-task-runner"
  role          = aws_iam_role.lambda_role.arn
  handler       = "index.lambda_handler"
  runtime       = "python3.11"
  timeout       = var.lambda_timeout
  memory_size   = var.lambda_memory

  vpc_config {
    subnet_ids         = aws_subnet.private[*].id
    security_group_ids = [aws_security_group.ecs.id]
  }

  environment {
    variables = {
      ECS_CLUSTER           = aws_ecs_cluster.main.name
      ECS_TASK_DEFINITION   = aws_ecs_task_definition.main.family
      ECS_SUBNETS           = join(",", aws_subnet.private[*].id)
      ECS_SECURITY_GROUPS   = aws_security_group.ecs.id
      TASK_EXECUTION_ROLE   = aws_iam_role.ecs_task_execution_role.arn
      TASK_ROLE             = aws_iam_role.ecs_task_role.arn
      AWS_REGION            = var.aws_region
    }
  }

  depends_on = [
    aws_iam_role_policy.lambda_ecs_policy
  ]

  tags = {
    Name = "${local.service_name}-task-runner"
  }
}

# Lambda Permission - API Gateway (if needed)
resource "aws_lambda_permission" "agent_invoker_api" {
  statement_id  = "AllowAPIGatewayInvoke"
  action        = "lambda:InvokeFunction"
  function_name = aws_lambda_function.agent_invoker.function_name
  principal     = "apigateway.amazonaws.com"
  source_arn    = "arn:aws:execute-api:${var.aws_region}:${data.aws_caller_identity.current.account_id}:*"
}

# API Gateway for Lambda
resource "aws_apigatewayv2_api" "main" {
  name          = "${local.service_name}-api"
  protocol_type = "HTTP"

  cors_configuration {
    allow_origins = ["*"]
    allow_methods = ["*"]
    allow_headers = ["*"]
  }

  tags = {
    Name = "${local.service_name}-api"
  }
}

# API Gateway Integration with Lambda
resource "aws_apigatewayv2_integration" "lambda_agent_invoker" {
  api_id                   = aws_apigatewayv2_api.main.id
  integration_type         = "AWS_PROXY"
  integration_method       = "POST"
  integration_uri          = aws_lambda_function.agent_invoker.invoke_arn
  payload_format_version   = "2.0"
}

# API Gateway Route
resource "aws_apigatewayv2_route" "invoke_agent" {
  api_id    = aws_apigatewayv2_api.main.id
  route_key = "POST /invoke-agent"
  target    = "integrations/${aws_apigatewayv2_integration.lambda_agent_invoker.id}"
}

# API Gateway Stage
resource "aws_apigatewayv2_stage" "main" {
  api_id      = aws_apigatewayv2_api.main.id
  name        = var.environment
  auto_deploy = true

  access_log_settings {
    destination_arn = aws_cloudwatch_log_group.api_gateway.arn
    format = jsonencode({
      requestId      = "$context.requestId"
      ip             = "$context.identity.sourceIp"
      requestTime    = "$context.requestTime"
      httpMethod     = "$context.httpMethod"
      resourcePath   = "$context.resourcePath"
      status         = "$context.status"
      protocol       = "$context.protocol"
      responseLength = "$context.responseLength"
    })
  }
}

# CloudWatch Log Group for API Gateway
resource "aws_cloudwatch_log_group" "api_gateway" {
  name              = "/aws/apigateway/${local.service_name}"
  retention_in_days = 7

  tags = {
    Name = "${local.service_name}-api-logs"
  }
}
