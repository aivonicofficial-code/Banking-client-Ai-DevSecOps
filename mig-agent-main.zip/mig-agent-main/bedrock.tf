# Create Bedrock Agent Role
resource "aws_iam_role" "bedrock_agent_role" {
  name = "${local.service_name}-bedrock-agent-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "bedrock.amazonaws.com"
        }
      }
    ]
  })
}

# Policy for Bedrock Agent to invoke models
resource "aws_iam_role_policy" "bedrock_agent_policy" {
  name = "${local.service_name}-bedrock-agent-policy"
  role = aws_iam_role.bedrock_agent_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel"
        ]
        Resource = "arn:aws:bedrock:${var.aws_region}::foundation-model/*"
      }
    ]
  })
}

# Bedrock Agent
resource "aws_bedrockagent_agent" "main" {
  agent_name                 = var.bedrock_agent_name
  agent_resource_role_arn    = aws_iam_role.bedrock_agent_role.arn
  description                = var.agent_description
  instruction                = var.agent_instruction
  idle_session_ttl_in_seconds = 900
  foundation_model           = var.bedrock_foundational_model

  tags = {
    Name = local.service_name
  }

  depends_on = [aws_iam_role_policy.bedrock_agent_policy]
}
