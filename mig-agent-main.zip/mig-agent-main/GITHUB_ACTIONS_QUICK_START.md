# GitHub Actions Workflows - Quick Setup

## 📋 What's Included

6 automated GitHub Actions workflows for complete CI/CD:

1. **terraform-plan.yml** - Validate on PRs
2. **terraform-apply.yml** - Deploy on merge to main
3. **docker-build.yml** - Build and push Docker images
4. **code-quality.yml** - Linting and security scanning
5. **manual-deployment.yml** - On-demand deployments
6. **health-check.yml** - Daily infrastructure checks

## 🚀 Quick Start (5 minutes)

### Step 1: Generate AWS Credentials (Choose One)

**Option A: OIDC (Recommended - More Secure)**

```bash
# Get your GitHub account ID
GITHUB_ACCOUNT="aravind8ai"
GITHUB_REPO="mig-agent"
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)

# Create OIDC provider
aws iam create-open-id-connect-provider \
  --url https://token.actions.githubusercontent.com \
  --client-id-list sts.amazonaws.com \
  --thumbprint-list 6938fd4d98bab03faadb97b34396831e3780aea1

# Create trust policy
cat > trust-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Federated": "arn:aws:iam::ACCOUNT_ID:oidc-provider/token.actions.githubusercontent.com"
      },
      "Action": "sts:AssumeRoleWithWebIdentity",
      "Condition": {
        "StringEquals": {
          "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
        },
        "StringLike": {
          "token.actions.githubusercontent.com:sub": "repo:GITHUB_ACCOUNT/GITHUB_REPO:*"
        }
      }
    }
  ]
}
EOF

# Create IAM role
aws iam create-role \
  --role-name github-actions-bedrock-agent \
  --assume-role-policy-document file://trust-policy.json

# Get role ARN
ROLE_ARN=$(aws iam get-role --role-name github-actions-bedrock-agent --query 'Role.Arn' --output text)
echo "Role ARN: $ROLE_ARN"
```

**Option B: Access Keys (Simpler)**

```bash
# Create IAM user
aws iam create-user --user-name github-actions-bedrock

# Create access key
aws iam create-access-key --user-name github-actions-bedrock

# Attach policy (save output)
aws iam put-user-policy \
  --user-name github-actions-bedrock \
  --policy-name bedrock-deployment \
  --policy-document file://github-actions-policy.json
```

### Step 2: Create S3 Bucket for Terraform State

```bash
BUCKET_NAME="bedrock-agent-tf-state-$(date +%s)"

aws s3 mb s3://${BUCKET_NAME}

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket ${BUCKET_NAME} \
  --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
  --bucket ${BUCKET_NAME} \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}
    }]
  }'

echo "Bucket: ${BUCKET_NAME}"
```

### Step 3: Create DynamoDB Table for Locking

```bash
aws dynamodb create-table \
  --table-name bedrock-agent-tf-locks \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST
```

### Step 4: Create ECR Repository

```bash
aws ecr create-repository \
  --repository-name bedrock-agent \
  --region us-east-1

# Get URI
ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
ECR_URI="${ACCOUNT_ID}.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest"
echo "ECR URI: ${ECR_URI}"
```

### Step 5: Add GitHub Secrets

Go to: **Settings → Secrets and variables → Actions → New repository secret**

Add these secrets:

```
AWS_ROLE_ARN = arn:aws:iam::ACCOUNT_ID:role/github-actions-bedrock-agent
(or use AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY instead)

CONTAINER_IMAGE_URI = 123456789.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest
TF_STATE_BUCKET = bedrock-agent-tf-state-xxx
TF_STATE_LOCK_TABLE = bedrock-agent-tf-locks
```

### Step 6: Add GitHub Variables

Go to: **Settings → Secrets and variables → Variables → New repository variable**

Add:

```
AWS_REGION = us-east-1
```

### Step 7: Create GitHub Environments (Optional)

Go to: **Settings → Environments → New environment**

Create: `dev`, `staging`, `prod`

For each environment, add required secrets.

## 📊 Workflow Triggers

| Workflow | Trigger | Action |
|----------|---------|--------|
| terraform-plan | Pull Request | Plan changes |
| terraform-apply | Push to main | Apply changes |
| docker-build | Docker file changes | Build & push image |
| code-quality | Every push | Lint & scan |
| manual-deployment | Manual trigger | Deploy to env |
| health-check | Daily @ 2 AM UTC | Check infrastructure |

## 🔧 Test the Setup

### 1. Create a Feature Branch

```bash
git checkout -b test/workflow
echo "# Test" >> README.md
git add .
git commit -m "Test GitHub Actions"
git push origin test/workflow
```

### 2. Create Pull Request

Visit your repo on GitHub and create a PR. Watch the workflows run!

### 3. Check Logs

**Actions tab** → Select workflow → View logs

Expected results:
- ✅ Terraform plan succeeds
- ✅ Code quality checks pass
- ✅ Comments added to PR with results

### 4. Merge to Main

Once approved, merge the PR. This triggers:
- ✅ terraform-apply (automatic)
- ✅ Infrastructure deployed

## 📋 Required IAM Policy

If using access keys, attach this policy:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:*",
        "ecs:*",
        "lambda:*",
        "apigateway:*",
        "ec2:*",
        "iam:*",
        "logs:*",
        "ecr:*",
        "s3:*",
        "dynamodb:*",
        "cloudformation:*"
      ],
      "Resource": "*"
    }
  ]
}
```

## 🆘 Troubleshooting

### Workflow stuck on "set-upstream"

```bash
# Already fixed by manual-deployment.yml
# Or manually push:
git push -u origin main
```

### Authentication Failed

Check:
1. `AWS_ROLE_ARN` is correct format
2. Repository URL matches in OIDC trust policy
3. AWS region is correct

### Terraform State Lock

```bash
# Check locks
aws dynamodb scan \
  --table-name bedrock-agent-tf-locks

# Remove stuck lock
aws dynamodb delete-item \
  --table-name bedrock-agent-tf-locks \
  --key '{"LockID":{"S":"lockid"}}'
```

### Docker Push Fails

1. Verify ECR repository exists
2. Check ECR URI in secrets
3. Ensure AWS has ecr:* permissions

## 📈 Monitor Deployments

1. **Actions Tab**: View all workflow runs
2. **Deployments Tab**: See deployment history
3. **CloudWatch Logs**: Check application logs
4. **AWS Console**: Verify resources

## 🎯 Next Steps

1. ✅ Add secrets to GitHub
2. ✅ Create S3 and DynamoDB
3. ✅ Test by creating a PR
4. ✅ Merge to main for auto-deploy
5. ✅ Monitor deployment in Actions tab

## 📚 Additional Resources

- [GitHub Actions Documentation](https://docs.github.com/actions)
- [AWS Actions for GitHub](https://github.com/aws-actions)
- [Terraform GitHub Actions](https://github.com/hashicorp/setup-terraform)
- [Project Documentation](./GITHUB_ACTIONS_SETUP.md)

## 💡 Tips

- **Test locally first**: Run `terraform plan` locally before pushing
- **Use branches**: Always use feature branches for testing
- **Review PRs**: Let workflows run before merging
- **Monitor costs**: Set up AWS billing alerts
- **Regular backups**: Daily backups are automated

---

**All set!** Your CI/CD pipeline is ready. Push a change to test it out! 🚀
