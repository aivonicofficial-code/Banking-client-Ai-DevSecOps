# Project Structure and File Guide

## Complete File Listing

### Terraform Configuration Files

1. **main.tf** (53 lines)
   - AWS provider configuration
   - Local variables
   - Default tags for all resources

2. **variables.tf** (117 lines)
   - Input variables for the infrastructure
   - Configurable parameters for all components
   - Default values for development

3. **networking.tf** (220 lines)
   - VPC, subnets, and routing configuration
   - Internet Gateway and NAT Gateway
   - Security groups for ALB and ECS
   - Availability zone data source

4. **iam.tf** (147 lines)
   - IAM roles for ECS tasks
   - IAM roles for Lambda functions
   - IAM roles for Bedrock agent
   - Policies for Bedrock, ECS, and CloudWatch access

5. **bedrock.tf** (48 lines)
   - Bedrock agent creation
   - Agent IAM role and policies
   - Outputs for agent ID and ARN

6. **ecs.tf** (262 lines)
   - ECS cluster, service, and task definition
   - Application Load Balancer configuration
   - Target groups and listeners
   - Auto-scaling policies for CPU and memory

7. **lambda.tf** (193 lines)
   - Lambda functions for agent invocation and task running
   - API Gateway HTTP API configuration
   - Integration with Lambda functions
   - CloudWatch logging for API Gateway

8. **outputs.tf** (47 lines)
   - Output values for deployed infrastructure
   - ALB DNS name, ECS cluster info
   - API Gateway endpoint, Lambda function names
   - Bedrock agent ID and ARN

9. **terraform.tfvars** (24 lines)
   - Configuration values for this deployment
   - ECR image URI, Bedrock settings
   - Resource sizing, network configuration
   - Lambda timeout and memory

### Python Application Files

10. **strands_app.py** (283 lines)
    - Main Strands framework application
    - StrandsAgent class for Bedrock integration
    - Task execution and management
    - Async/await support for concurrent operations

11. **lambda_agent_invoker.py** (196 lines)
    - Lambda handler for invoking Bedrock agents
    - Session management
    - Response stream processing
    - Agent details retrieval

12. **lambda_task_runner.py** (240 lines)
    - Lambda handler for running ECS tasks
    - Task command execution
    - Environment variable injection
    - Task completion monitoring

### Docker and Dependencies

13. **Dockerfile** (24 lines)
    - Multi-stage Python 3.11 image
    - Application dependencies installation
    - Health check configuration
    - Container port exposure

14. **requirements.txt** (5 lines)
    - Python package dependencies
    - boto3 for AWS SDK
    - asyncio and aiohttp libraries

### Deployment Scripts

15. **deploy.sh** (156 lines)
    - Bash deployment automation script
    - Docker image build and push to ECR
    - Lambda function packaging
    - Terraform initialization and deployment
    - Interactive confirmation prompts

16. **deploy.ps1** (174 lines)
    - PowerShell deployment automation script
    - Windows-compatible script
    - Same functionality as deploy.sh
    - Uses 7z for compression

### Documentation

17. **README.md** (406 lines)
    - Comprehensive project documentation
    - Architecture overview with diagrams
    - Component descriptions
    - Prerequisites and deployment instructions
    - Usage examples and API calls
    - Monitoring and scaling guidance
    - Troubleshooting section

18. **ARCHITECTURE.md** (378 lines)
    - Detailed architecture documentation
    - Component descriptions and design decisions
    - Data flow diagrams
    - Scaling considerations
    - Cost estimation
    - Disaster recovery procedures
    - Best practices
    - Security considerations

19. **examples.py** (396 lines)
    - Comprehensive usage examples
    - API Gateway invocation examples
    - Lambda direct invocation
    - Multi-turn conversations
    - Batch processing patterns
    - Error handling examples
    - Agent information retrieval

### Configuration and Ignore Files

20. **.gitignore** (43 lines)
    - Terraform state files
    - IDE configuration
    - Lambda deployment packages
    - Python artifacts
    - AWS credentials
    - Environment files

## Quick Navigation Guide

### Getting Started
1. Start with: [README.md](README.md)
2. Review architecture: [ARCHITECTURE.md](ARCHITECTURE.md)
3. Customize: [terraform.tfvars](terraform.tfvars)

### Deployment
1. For Linux/Mac: Run `./deploy.sh`
2. For Windows: Run `./deploy.ps1`
3. Or manually: Run Terraform commands in [main.tf](main.tf)

### Understanding the Code
1. Infrastructure: [ecs.tf](ecs.tf), [networking.tf](networking.tf)
2. Bedrock Integration: [bedrock.tf](bedrock.tf)
3. API Layer: [lambda.tf](lambda.tf)
4. Application: [strands_app.py](strands_app.py)

### Testing and Usage
1. Review examples: [examples.py](examples.py)
2. Check Lambda functions: [lambda_agent_invoker.py](lambda_agent_invoker.py), [lambda_task_runner.py](lambda_task_runner.py)
3. Container setup: [Dockerfile](Dockerfile), [requirements.txt](requirements.txt)

## File Dependencies

```
Main Infrastructure
├── main.tf (provider setup)
├── variables.tf (input variables)
├── networking.tf (VPC resources)
├── iam.tf (security roles)
├── bedrock.tf (Bedrock agent)
├── ecs.tf (container orchestration)
└── lambda.tf (serverless compute)

Application Layer
├── strands_app.py (main application)
├── lambda_agent_invoker.py (Lambda function)
├── lambda_task_runner.py (Lambda function)
├── Dockerfile (container image)
└── requirements.txt (dependencies)

Deployment
├── deploy.sh (Linux/Mac automation)
├── deploy.ps1 (Windows automation)
└── terraform.tfvars (configuration)

Documentation
├── README.md (getting started)
├── ARCHITECTURE.md (technical details)
└── examples.py (usage patterns)
```

## Total Project Size

- **Terraform Code**: ~950 lines
- **Python Code**: ~715 lines
- **Documentation**: ~784 lines
- **Configuration Files**: ~72 lines
- **Total**: ~2,521 lines of code and documentation

## Environment Variables Used

### Terraform Variables
- `AWS_REGION`: AWS region (default: us-east-1)
- `PROJECT_NAME`: Project identifier (default: bedrock-agent)
- `ENVIRONMENT`: Deployment environment (default: dev)

### Application Environment Variables
- `BEDROCK_AGENT_ID`: ID of the Bedrock agent
- `AWS_REGION`: AWS region
- `ECS_CLUSTER`: ECS cluster name
- `ECS_TASK_DEFINITION`: ECS task definition name
- `PYTHONUNBUFFERED`: Set to 1 for unbuffered output

### Lambda Environment Variables
- `BEDROCK_AGENT_ID`: Agent ID for invocation
- `AWS_REGION`: AWS region
- `ECS_CLUSTER`: ECS cluster for task execution
- `ECS_TASK_DEFINITION`: Task definition to run
- `ECS_SUBNETS`: Comma-separated subnet IDs
- `ECS_SECURITY_GROUPS`: Security group ID
- `TASK_EXECUTION_ROLE`: IAM role ARN
- `TASK_ROLE`: IAM role ARN

## Key Features Provided

✅ Bedrock Agent Integration
✅ ECS Fargate Cluster
✅ API Gateway with Lambda
✅ Automatic Scaling
✅ Multi-AZ High Availability
✅ VPC Networking
✅ CloudWatch Monitoring
✅ IAM Security
✅ Docker Container Support
✅ Terraform Infrastructure as Code
✅ Complete Documentation
✅ Deployment Automation
✅ Usage Examples
✅ Error Handling
✅ Logging and Debugging

## Support and Maintenance

### Regular Maintenance Tasks
- Review CloudWatch logs weekly
- Check auto-scaling metrics monthly
- Update container image as needed
- Review IAM policies quarterly

### Monitoring
- Set up CloudWatch alarms for error rates
- Track Bedrock token usage
- Monitor ECS task failures
- Review Lambda duration trends

### Updates
- Keep Terraform provider updated
- Update Python dependencies regularly
- Review AWS service updates
- Apply security patches
