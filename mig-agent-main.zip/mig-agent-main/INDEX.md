# AWS Bedrock Agent with ECS Fargate and Lambda - Complete Project

## 📋 Project Overview

This is a **production-ready Terraform-based infrastructure** for deploying AWS Bedrock agents on ECS Fargate with Lambda API integration using the Strands framework. The project provides autonomous agent execution, serverless container orchestration, and API-driven task management.

## 🎯 Key Features

✅ **Bedrock Agent Integration** - AWS Bedrock agent with Claude foundation model
✅ **ECS Fargate** - Serverless container orchestration with auto-scaling
✅ **Lambda Functions** - Serverless API layer for agent invocation and task execution
✅ **API Gateway** - HTTP REST API for agent interaction
✅ **High Availability** - Multi-AZ deployment with auto-scaling
✅ **Security** - VPC isolation, IAM roles, security groups
✅ **Monitoring** - CloudWatch logs, metrics, and alarms
✅ **Cost Optimized** - Estimated $60-150/month for development
✅ **Infrastructure as Code** - Complete Terraform configuration
✅ **Automated Deployment** - Bash and PowerShell scripts
✅ **Complete Documentation** - Architecture, examples, troubleshooting
✅ **Python Application** - Strands framework integration example

## 📁 Project Structure

```
mig-agent/
├── 📄 Infrastructure Files (Terraform)
│   ├── main.tf                 # Provider and configuration
│   ├── variables.tf            # Input variables
│   ├── outputs.tf              # Output values
│   ├── networking.tf           # VPC and networking
│   ├── iam.tf                  # Security roles and policies
│   ├── bedrock.tf              # Bedrock agent setup
│   ├── ecs.tf                  # ECS Fargate configuration
│   ├── lambda.tf               # Lambda functions and API Gateway
│   └── terraform.tfvars        # Configuration values
│
├── 🐍 Application Files (Python)
│   ├── strands_app.py          # Main Strands framework application
│   ├── lambda_agent_invoker.py # Lambda for Bedrock invocation
│   ├── lambda_task_runner.py   # Lambda for ECS task execution
│   ├── examples.py             # Usage examples and patterns
│   ├── Dockerfile              # Container image definition
│   └── requirements.txt        # Python dependencies
│
├── 🚀 Deployment Scripts
│   ├── deploy.sh               # Bash deployment automation
│   └── deploy.ps1              # PowerShell deployment automation
│
├── 📚 Documentation
│   ├── README.md               # Getting started guide
│   ├── ARCHITECTURE.md         # Technical architecture
│   ├── FILE_GUIDE.md           # File structure guide
│   ├── TROUBLESHOOTING.md      # Troubleshooting and FAQ
│   └── INDEX.md                # This file
│
└── .gitignore                  # Git ignore patterns
```

## 🚀 Quick Start

### Prerequisites
- AWS Account with appropriate permissions
- Terraform >= 1.0
- AWS CLI v2
- Docker
- Git (optional)

### 1. Clone or Setup Project
```bash
cd c:\Users\Aravind\Documents\project\2026\mig-agent
```

### 2. Configure Variables
Edit `terraform.tfvars`:
```hcl
aws_region             = "us-east-1"
project_name           = "bedrock-agent"
environment            = "dev"
container_image_uri    = "YOUR_ECR_URI"
```

### 3. Deploy (Automatic)
**Linux/Mac:**
```bash
chmod +x deploy.sh
./deploy.sh
```

**Windows:**
```powershell
.\deploy.ps1
```

### 4. Deploy (Manual)
```bash
terraform init
terraform plan
terraform apply
```

## 📊 Architecture

```
┌─────────────────────────────────────────┐
│          API Gateway (HTTP)              │
└────────────────────┬────────────────────┘
                     │
        ┌────────────┴────────────┐
        ▼                         ▼
    ┌─────────┐            ┌──────────┐
    │ Lambda  │            │ Lambda   │
    │ Invoker │            │ Runner   │
    └────┬────┘            └────┬─────┘
         │                      │
    ┌────▼──────────┐      ┌────▼────────────┐
    │ Bedrock Agent │      │ ECS Fargate     │
    │ (Claude 3)    │      │ (Strands App)   │
    └───────────────┘      └─────────────────┘
```

## 🔧 Configuration

### Key Variables (terraform.tfvars)

| Variable | Default | Description |
|----------|---------|-------------|
| `aws_region` | us-east-1 | AWS region |
| `project_name` | bedrock-agent | Project identifier |
| `environment` | dev | Environment name |
| `container_cpu` | 512 | ECS task CPU units |
| `container_memory` | 1024 | ECS task memory (MB) |
| `ecs_desired_count` | 2 | Desired ECS tasks |
| `lambda_timeout` | 300 | Lambda timeout (seconds) |
| `lambda_memory` | 512 | Lambda memory (MB) |

### Environment Variables

**Application:**
- `BEDROCK_AGENT_ID` - Agent ID for Bedrock
- `AWS_REGION` - AWS region
- `ECS_CLUSTER` - ECS cluster name

**Lambda:**
- `BEDROCK_AGENT_ID` - For agent invocation
- `ECS_CLUSTER` - For task execution
- `ECS_TASK_DEFINITION` - Task definition name

## 📖 Documentation Guide

### Getting Started
1. **[README.md](README.md)** - Complete setup and deployment guide
2. **[ARCHITECTURE.md](ARCHITECTURE.md)** - Technical architecture and design decisions

### Usage and Development
3. **[examples.py](examples.py)** - Practical usage examples
4. **[FILE_GUIDE.md](FILE_GUIDE.md)** - Complete file reference

### Support and Troubleshooting
5. **[TROUBLESHOOTING.md](TROUBLESHOOTING.md)** - Common issues and solutions

## 💡 Usage Examples

### Invoke Agent via API
```bash
curl -X POST https://your-api.execute-api.us-east-1.amazonaws.com/dev/invoke-agent \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "session-001",
    "user_input": "Analyze the sales data"
  }'
```

### Run ECS Task via Lambda
```bash
aws lambda invoke \
  --function-name bedrock-agent-dev-task-runner \
  --payload '{"body":{"task_command":["python","app.py"]}}' \
  response.json
```

### Multi-turn Conversation
```python
# See examples.py for detailed multi-turn conversation example
```

## 📊 Output Values

After deployment, retrieve outputs:
```bash
terraform output alb_dns_name              # Load balancer DNS
terraform output api_gateway_endpoint      # API endpoint
terraform output bedrock_agent_id          # Agent ID
terraform output ecs_cluster_name          # ECS cluster
```

## 🔐 Security Features

- **VPC Isolation**: ECS tasks in private subnets
- **IAM Roles**: Least privilege access control
- **Security Groups**: Restrictive inbound/outbound rules
- **Secrets Management**: AWS Secrets Manager ready
- **CloudTrail**: Audit logging available
- **VPC Flow Logs**: Network monitoring enabled

## 📈 Scaling

### Automatic Scaling
- **CPU-based**: Target 70% utilization (2-4 tasks)
- **Memory-based**: Target 80% utilization (2-4 tasks)
- **Lambda**: Automatic by AWS (1000 concurrent)

### Manual Scaling
```hcl
# Update in terraform.tfvars
ecs_desired_count = 4
container_cpu = 1024
container_memory = 2048
```

## 💰 Cost Estimation

| Component | Cost/Month | Notes |
|-----------|-----------|-------|
| ECS Fargate | $20-50 | 2 tasks @ 512 CPU, 1GB |
| NAT Gateway | $30 | Data transfer |
| Lambda | $5-20 | Variable requests |
| API Gateway | $3.50 | Per million requests |
| CloudWatch | $5-10 | Logs and metrics |
| **Total** | **$63-150** | Development environment |

*Production costs may be higher with increased scaling and data transfer.*

## 🆘 Getting Help

### Documentation
- [AWS Bedrock Docs](https://docs.aws.amazon.com/bedrock/)
- [ECS Fargate Docs](https://docs.aws.amazon.com/ecs/)
- [Terraform AWS Docs](https://registry.terraform.io/providers/hashicorp/aws/latest)

### Troubleshooting
- Check [TROUBLESHOOTING.md](TROUBLESHOOTING.md) for common issues
- Review CloudWatch logs: `aws logs tail /ecs/bedrock-agent-dev --follow`
- Monitor metrics in AWS Console

### Support Resources
- AWS Support (Business/Enterprise plans)
- GitHub Issues (if this is a repository)
- Stack Overflow (tag: amazon-bedrock)
- AWS Forums

## 📋 Deployment Checklist

- [ ] AWS credentials configured
- [ ] AWS account has Bedrock access
- [ ] Terraform installed (v1.0+)
- [ ] Docker installed and running
- [ ] AWS CLI v2 installed
- [ ] Review terraform.tfvars configuration
- [ ] Run deployment script (or manual Terraform)
- [ ] Verify resource creation
- [ ] Test API endpoint
- [ ] Monitor CloudWatch logs

## 🔄 Maintenance

### Regular Tasks
- **Weekly**: Review CloudWatch logs for errors
- **Monthly**: Check auto-scaling metrics
- **Quarterly**: Review IAM policies
- **As needed**: Update container images

### Monitoring
```bash
# Watch ECS logs
aws logs tail /ecs/bedrock-agent-dev --follow

# Watch Lambda logs
aws logs tail /aws/lambda/bedrock-agent-dev-agent-invoker --follow

# Check resource status
terraform state list
terraform state show
```

### Cleanup
```bash
# Destroy all resources
terraform destroy

# Remove ECR repository
aws ecr delete-repository --repository-name bedrock-agent --force
```

## 📝 Project Statistics

| Metric | Value |
|--------|-------|
| Total Files | 22 |
| Terraform Code | ~950 lines |
| Python Code | ~715 lines |
| Documentation | ~784 lines |
| Total Size | ~100 KB |
| Deployment Time | ~5-10 minutes |

## 🎓 Learning Resources

- **Strands Framework**: Learn about autonomous agents
- **Bedrock**: AWS AI/ML service documentation
- **ECS Fargate**: Container orchestration patterns
- **Lambda**: Serverless architecture patterns
- **Terraform**: Infrastructure as Code practices

## 📜 License

This project is provided as-is for use with AWS Bedrock and AWS services.

## 🤝 Contributing

To improve this project:
1. Review existing implementation
2. Test changes thoroughly
3. Document modifications
4. Update relevant files

## 📞 Contact and Support

For issues or questions:
- Review [TROUBLESHOOTING.md](TROUBLESHOOTING.md)
- Check AWS documentation
- Review examples in [examples.py](examples.py)
- Check CloudWatch logs for debugging

---

## Next Steps

1. **Setup**: Follow [README.md](README.md) for deployment
2. **Learn**: Review [ARCHITECTURE.md](ARCHITECTURE.md)
3. **Test**: Try examples in [examples.py](examples.py)
4. **Deploy**: Run deployment script or Terraform
5. **Monitor**: Watch CloudWatch logs and metrics
6. **Scale**: Adjust resources as needed

---

**Last Updated**: 2024-04-18
**Version**: 1.0.0
**Status**: Production Ready
