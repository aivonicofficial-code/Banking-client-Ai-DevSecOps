# GitHub Actions Configuration Guide

## Required Secrets

Add these secrets to your GitHub repository (Settings → Secrets and variables → Actions):

### AWS Credentials
- `AWS_ROLE_ARN` - ARN of the IAM role for OIDC (GitHub Actions)
- `AWS_ACCESS_KEY_ID` - (Alternative if not using OIDC)
- `AWS_SECRET_ACCESS_KEY` - (Alternative if not using OIDC)
- `CONTAINER_IMAGE_URI` - ECR image URI (format: `ACCOUNT_ID.dkr.ecr.REGION.amazonaws.com/bedrock-agent:latest`)
- `TF_STATE_BUCKET` - S3 bucket for Terraform state
- `TF_STATE_LOCK_TABLE` - DynamoDB table for state locking

### Optional Secrets
- `SLACK_WEBHOOK` - For Slack notifications (if using)
- `GITHUB_TOKEN` - Automatically provided by GitHub

## Required Variables

Add these variables to your GitHub repository (Settings → Secrets and variables → Variables):

- `AWS_REGION` - AWS region (default: us-east-1)

## Setup Instructions

### 1. Create S3 Bucket for Terraform State

```bash
aws s3 mb s3://bedrock-agent-terraform-state-$(date +%s)

# Enable versioning
aws s3api put-bucket-versioning \
  --bucket bedrock-agent-terraform-state-xxx \
  --versioning-configuration Status=Enabled

# Enable encryption
aws s3api put-bucket-encryption \
  --bucket bedrock-agent-terraform-state-xxx \
  --server-side-encryption-configuration '{
    "Rules": [{
      "ApplyServerSideEncryptionByDefault": {
        "SSEAlgorithm": "AES256"
      }
    }]
  }'
```

### 2. Create DynamoDB Table for State Locking

```bash
aws dynamodb create-table \
  --table-name bedrock-agent-terraform-locks \
  --attribute-definitions AttributeName=LockID,AttributeType=S \
  --key-schema AttributeName=LockID,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST
```

### 3. Create IAM Role for GitHub Actions (OIDC)

```bash
# Create the role
aws iam create-role \
  --role-name github-actions-bedrock-agent \
  --assume-role-policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Principal": {
          "Federated": "arn:aws:iam::ACCOUNT_ID:oidc-provider/token.actions.githubusercontent.com"
        },
        "Action": "sts:AssumeRoleWithWebIdentity",
        "Condition": {
          "StringEquals": {
            "token.actions.githubusercontent.com:aud": "sts.amazonaws.com"
          },
          "StringLike": {
            "token.actions.githubusercontent.com:sub": "repo:aravind8ai/mig-agent:*"
          }
        }
      }
    ]
  }'

# Create policy
aws iam put-role-policy \
  --role-name github-actions-bedrock-agent \
  --policy-name github-actions-policy \
  --policy-document '{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Action": [
          "sts:AssumeRole"
        ],
        "Resource": "arn:aws:iam::ACCOUNT_ID:role/github-actions-bedrock-agent"
      },
      {
        "Effect": "Allow",
        "Action": [
          "s3:*",
          "dynamodb:*",
          "bedrock:*",
          "ecs:*",
          "lambda:*",
          "apigateway:*",
          "ec2:*",
          "iam:*",
          "logs:*",
          "ecr:*"
        ],
        "Resource": "*"
      }
    ]
  }'
```

### 4. Add Secrets to GitHub

Go to your repository → Settings → Secrets and variables → Actions → New repository secret

```
AWS_ROLE_ARN=arn:aws:iam::ACCOUNT_ID:role/github-actions-bedrock-agent
CONTAINER_IMAGE_URI=ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest
TF_STATE_BUCKET=bedrock-agent-terraform-state-xxx
TF_STATE_LOCK_TABLE=bedrock-agent-terraform-locks
```

## Workflow Files

### 1. terraform-plan.yml
- Triggers on: Pull requests
- Action: Validates and plans Terraform changes
- Posts results to PR

### 2. terraform-apply.yml
- Triggers on: Push to main branch
- Action: Applies Terraform changes automatically
- Manual dispatch for custom environments

### 3. docker-build.yml
- Triggers on: Changes to Dockerfile, requirements.txt, strands_app.py
- Action: Builds Docker image and pushes to ECR
- Runs security scans

### 4. code-quality.yml
- Triggers on: Every push and PR
- Action: Linting and security scanning
- Checks: TFLint, Flake8, Bandit, ShellCheck

### 5. manual-deployment.yml
- Triggers: Manual workflow dispatch
- Actions: Plan, Apply, or Destroy
- Environments: dev, staging, prod

### 6. health-check.yml
- Triggers on: Daily schedule
- Action: Checks infrastructure health
- Creates backups

## GitHub Environments

Create three environments for better control:

1. **dev** - Development environment
2. **staging** - Staging environment
3. **prod** - Production environment

For each environment, add required secrets and set protection rules.

## Workflow Usage

### 1. Create and Push Feature Branch

```bash
git checkout -b feature/new-feature
# Make changes
git commit -m "Add new feature"
git push origin feature/new-feature
```

### 2. Create Pull Request

GitHub will automatically:
- Run terraform-plan
- Run code-quality checks
- Run docker-build (if applicable)
- Post results to PR

### 3. Review and Merge

After approval, merge to main. This triggers:
- terraform-apply (automatic)
- docker-build and push to ECR
- health-check (daily)

### 4. Manual Deployment

Go to Actions → Manual Deployment → Run workflow

Choose:
- Environment: dev, staging, or prod
- Action: plan, apply, or destroy
- Auto approve: yes/no

## Monitoring Workflows

1. Go to your repository → Actions tab
2. View workflow runs and logs
3. Check "Summary" for deployment details

## Troubleshooting

### Workflow Fails to Authenticate

Check:
1. AWS Role ARN is correct
2. OIDC provider is configured
3. Repository URL in assume role matches

### Terraform State Lock

If locked:
```bash
aws dynamodb scan \
  --table-name bedrock-agent-terraform-locks

aws dynamodb delete-item \
  --table-name bedrock-agent-terraform-locks \
  --key '{"LockID":{"S":"your-lock-id"}}'
```

### Docker Push Fails

Check:
1. ECR repository exists
2. AWS credentials have ECR permissions
3. Container image URI is correct

## Cost Optimization

- Workflows run on GitHub-hosted runners (free for public repos)
- Terraform state stored in S3 (~$0.023/GB/month)
- DynamoDB pay-per-request billing (~$1.25/million requests)

## Next Steps

1. Add secrets to GitHub
2. Create S3 and DynamoDB resources
3. Set up OIDC role
4. Create GitHub environments
5. Test by creating a PR
6. Merge to main for first deployment
