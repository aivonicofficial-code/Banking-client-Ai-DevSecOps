aws_region        = "us-east-1"
project_name      = "bedrock-agent"
environment       = "dev"
container_cpu     = 512
container_memory  = 1024
ecs_desired_count = 2

# Replace with your actual Docker image URI
container_image_uri = "ACCOUNT_ID.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest"

bedrock_agent_name      = "strands-agent"
bedrock_foundational_model = "anthropic.claude-3-sonnet-20240229-v1:0"

vpc_cidr           = "10.0.0.0/16"
public_subnet_cidrs = ["10.0.101.0/24", "10.0.102.0/24"]
private_subnet_cidrs = ["10.0.1.0/24", "10.0.2.0/24"]
enable_nat_gateway = true

lambda_timeout = 300
lambda_memory  = 512
