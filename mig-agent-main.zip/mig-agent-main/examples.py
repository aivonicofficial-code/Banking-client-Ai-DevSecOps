"""
Example Usage Patterns for Bedrock Agent with Strands Framework

This file demonstrates various ways to interact with the deployed infrastructure.
"""

import json
import boto3
import requests
from typing import Dict, Any

# Initialize clients
bedrock_client = boto3.client('bedrock-agent-runtime')
lambda_client = boto3.client('lambda')
apigateway_client = boto3.client('apigatewayv2')

# Configuration (replace with your values)
API_ENDPOINT = "https://your-api-id.execute-api.us-east-1.amazonaws.com/dev"
BEDROCK_AGENT_ID = "your-agent-id"
LAMBDA_AGENT_INVOKER = "bedrock-agent-dev-agent-invoker"
LAMBDA_TASK_RUNNER = "bedrock-agent-dev-task-runner"


# ==================== Example 1: Invoke Agent via API Gateway ====================

def example_invoke_agent_via_api():
    """
    Invoke the Bedrock agent using the API Gateway endpoint.
    """
    print("Example 1: Invoke Agent via API Gateway\n")
    
    url = f"{API_ENDPOINT}/invoke-agent"
    
    payload = {
        "session_id": "session-001",
        "user_input": "Analyze the quarterly sales data for Q1 2024",
        "max_tokens": 2048
    }
    
    headers = {
        "Content-Type": "application/json"
    }
    
    response = requests.post(url, json=payload, headers=headers)
    
    if response.status_code == 200:
        result = response.json()
        print("Agent Response:")
        print(json.dumps(result, indent=2))
    else:
        print(f"Error: {response.status_code}")
        print(response.text)


# ==================== Example 2: Invoke Agent Directly via Lambda ====================

def example_invoke_agent_via_lambda():
    """
    Invoke the agent using the Lambda function directly.
    """
    print("\nExample 2: Invoke Agent via Lambda\n")
    
    payload = {
        "body": {
            "session_id": "session-002",
            "user_input": "Generate a comprehensive market analysis report",
            "agent_id": BEDROCK_AGENT_ID
        }
    }
    
    response = lambda_client.invoke(
        FunctionName=LAMBDA_AGENT_INVOKER,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )
    
    result = json.loads(response['Payload'].read())
    print("Lambda Response:")
    print(json.dumps(result, indent=2))


# ==================== Example 3: Run ECS Task ====================

def example_run_ecs_task():
    """
    Run an ECS task through the Lambda task runner.
    """
    print("\nExample 3: Run ECS Task\n")
    
    payload = {
        "body": {
            "task_command": ["python", "strands_app.py"],
            "environment_vars": {
                "ANALYSIS_TYPE": "detailed",
                "OUTPUT_FORMAT": "json"
            },
            "task_count": 1,
            "wait_for_completion": False
        }
    }
    
    response = lambda_client.invoke(
        FunctionName=LAMBDA_TASK_RUNNER,
        InvocationType='RequestResponse',
        Payload=json.dumps(payload)
    )
    
    result = json.loads(response['Payload'].read())
    print("Task Runner Response:")
    print(json.dumps(result, indent=2))
    
    # Extract task ARN for monitoring
    if 'body' in result:
        body = json.loads(result['body'])
        if 'tasks' in body:
            for task in body['tasks']:
                print(f"\nTask ARN: {task['task_arn']}")


# ==================== Example 4: Multi-turn Conversation ====================

def example_multi_turn_conversation():
    """
    Demonstrate a multi-turn conversation with the agent.
    """
    print("\nExample 4: Multi-turn Conversation\n")
    
    session_id = "session-conversation-001"
    conversation_history = []
    
    # Turn 1
    print("Turn 1: Ask for data analysis")
    payload = {
        "session_id": session_id,
        "user_input": "I need to analyze sales data for the past 12 months"
    }
    
    response = requests.post(
        f"{API_ENDPOINT}/invoke-agent",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    result = response.json()
    conversation_history.append({
        "user": payload["user_input"],
        "agent": result.get("output", "")
    })
    print(f"Agent: {result.get('output', '')[:200]}...\n")
    
    # Turn 2
    print("Turn 2: Follow-up question")
    payload = {
        "session_id": session_id,
        "user_input": "Can you break this down by region?"
    }
    
    response = requests.post(
        f"{API_ENDPOINT}/invoke-agent",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    result = response.json()
    conversation_history.append({
        "user": payload["user_input"],
        "agent": result.get("output", "")
    })
    print(f"Agent: {result.get('output', '')[:200]}...\n")
    
    # Turn 3
    print("Turn 3: Request specific action")
    payload = {
        "session_id": session_id,
        "user_input": "Generate a summary report with top insights"
    }
    
    response = requests.post(
        f"{API_ENDPOINT}/invoke-agent",
        json=payload,
        headers={"Content-Type": "application/json"}
    )
    
    result = response.json()
    conversation_history.append({
        "user": payload["user_input"],
        "agent": result.get("output", "")
    })
    print(f"Agent: {result.get('output', '')[:200]}...\n")
    
    print("Conversation History:")
    print(json.dumps(conversation_history, indent=2))


# ==================== Example 5: Batch Processing ====================

def example_batch_processing():
    """
    Process multiple tasks in batch using the task runner.
    """
    print("\nExample 5: Batch Processing\n")
    
    tasks = [
        {
            "task_name": "Daily Report Generation",
            "command": ["python", "strands_app.py", "--task", "daily_report"]
        },
        {
            "task_name": "Data Validation",
            "command": ["python", "strands_app.py", "--task", "validate_data"]
        },
        {
            "task_name": "Cache Refresh",
            "command": ["python", "strands_app.py", "--task", "refresh_cache"]
        }
    ]
    
    task_arns = []
    
    for task in tasks:
        print(f"Starting: {task['task_name']}")
        
        payload = {
            "body": {
                "task_command": task["command"],
                "environment_vars": {
                    "TASK_NAME": task["task_name"]
                }
            }
        }
        
        response = lambda_client.invoke(
            FunctionName=LAMBDA_TASK_RUNNER,
            InvocationType='Event',  # Asynchronous
            Payload=json.dumps(payload)
        )
        
        print(f"  Status: {response['StatusCode']}")
        
    print(f"\nStarted {len(tasks)} tasks asynchronously")


# ==================== Example 6: Error Handling ====================

def example_error_handling():
    """
    Demonstrate error handling patterns.
    """
    print("\nExample 6: Error Handling\n")
    
    try:
        # Missing required field
        payload = {
            "session_id": "session-001"
            # Missing "user_input"
        }
        
        response = requests.post(
            f"{API_ENDPOINT}/invoke-agent",
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        if response.status_code != 200:
            error_response = response.json()
            print(f"Error Response: {json.dumps(error_response, indent=2)}")
    
    except requests.exceptions.RequestException as e:
        print(f"Request Error: {str(e)}")
    
    except json.JSONDecodeError as e:
        print(f"JSON Decode Error: {str(e)}")


# ==================== Example 7: Get Agent Information ====================

def example_get_agent_info():
    """
    Retrieve information about the deployed agent.
    """
    print("\nExample 7: Get Agent Information\n")
    
    try:
        bedrock_agent_client = boto3.client('bedrock-agent')
        
        response = bedrock_agent_client.get_agent(agentId=BEDROCK_AGENT_ID)
        
        print(f"Agent ID: {response.get('agentId')}")
        print(f"Agent Name: {response.get('agentName')}")
        print(f"Status: {response.get('agentStatus')}")
        print(f"Foundation Model: {response.get('foundationModel')}")
        print(f"Description: {response.get('description')}")
        
    except Exception as e:
        print(f"Error: {str(e)}")


# ==================== Main ====================

if __name__ == "__main__":
    print("=" * 60)
    print("Bedrock Agent with Strands Framework - Usage Examples")
    print("=" * 60)
    
    # Run examples
    try:
        example_invoke_agent_via_api()
        example_invoke_agent_via_lambda()
        example_run_ecs_task()
        example_multi_turn_conversation()
        example_batch_processing()
        example_error_handling()
        example_get_agent_info()
    
    except Exception as e:
        print(f"\nError running examples: {str(e)}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 60)
    print("Examples completed")
    print("=" * 60)
