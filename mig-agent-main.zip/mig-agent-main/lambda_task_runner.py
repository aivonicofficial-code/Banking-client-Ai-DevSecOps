"""
Lambda function to run ECS tasks for executing agent-driven workflows.
This function starts ECS tasks that run the Strands framework application.
"""

import json
import boto3
import os
from typing import Dict, Any, List, Optional

ecs_client = boto3.client('ecs')

ECS_CLUSTER = os.environ.get('ECS_CLUSTER')
ECS_TASK_DEFINITION = os.environ.get('ECS_TASK_DEFINITION')
ECS_SUBNETS = os.environ.get('ECS_SUBNETS', '').split(',')
ECS_SECURITY_GROUPS = [os.environ.get('ECS_SECURITY_GROUPS')]
TASK_EXECUTION_ROLE = os.environ.get('TASK_EXECUTION_ROLE')
TASK_ROLE = os.environ.get('TASK_ROLE')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for running ECS tasks.
    
    Expected event structure:
    {
        "body": {
            "task_command": ["python", "app.py", "--input", "..."],
            "environment_vars": {
                "KEY": "VALUE"
            },
            "container_name": "string (optional)",
            "task_count": "number (optional, default 1)",
            "wait_for_completion": "boolean (optional, default false)"
        }
    }
    """
    try:
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Validate required fields
        task_command = body.get('task_command', [])
        
        if not task_command:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required field: task_command'
                })
            }
        
        # Run the ECS task
        task_response = run_ecs_task(
            task_command=task_command,
            environment_vars=body.get('environment_vars', {}),
            container_name=body.get('container_name'),
            task_count=body.get('task_count', 1),
            wait_for_completion=body.get('wait_for_completion', False)
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps(task_response)
        }
    
    except Exception as e:
        print(f"Error running ECS task: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'Failed to run ECS task: {str(e)}'
            })
        }


def run_ecs_task(
    task_command: List[str],
    environment_vars: Dict[str, str],
    container_name: Optional[str] = None,
    task_count: int = 1,
    wait_for_completion: bool = False
) -> Dict[str, Any]:
    """
    Run an ECS task with the given configuration.
    
    Args:
        task_command: Command to run in the container
        environment_vars: Environment variables to set
        container_name: Name of the container (uses task definition name if not provided)
        task_count: Number of tasks to run
        wait_for_completion: Whether to wait for task completion
    
    Returns:
        Response with task information
    """
    
    if not ECS_CLUSTER or not ECS_TASK_DEFINITION:
        raise ValueError("ECS_CLUSTER and ECS_TASK_DEFINITION environment variables must be set")
    
    # Prepare environment variables
    env_list = [
        {'name': key, 'value': value}
        for key, value in environment_vars.items()
    ]
    
    # Add default container name if not provided
    if not container_name:
        container_name = ECS_TASK_DEFINITION
    
    # Prepare override parameters
    overrides = {
        'containerOverrides': [
            {
                'name': container_name,
                'command': task_command,
                'environment': env_list
            }
        ]
    }
    
    # Run the task
    response = ecs_client.run_task(
        cluster=ECS_CLUSTER,
        taskDefinition=ECS_TASK_DEFINITION,
        count=task_count,
        launchType='FARGATE',
        networkConfiguration={
            'awsvpcConfiguration': {
                'subnets': ECS_SUBNETS,
                'securityGroups': ECS_SECURITY_GROUPS,
                'assignPublicIp': 'DISABLED'
            }
        },
        overrides=overrides
    )
    
    # Extract task information
    tasks_info = []
    for task in response.get('tasks', []):
        tasks_info.append({
            'task_arn': task.get('taskArn'),
            'task_definition': task.get('taskDefinitionArn'),
            'status': task.get('lastStatus'),
            'launched_at': task.get('createdAt').isoformat() if task.get('createdAt') else None
        })
    
    result = {
        'cluster': ECS_CLUSTER,
        'task_definition': ECS_TASK_DEFINITION,
        'tasks_count': len(tasks_info),
        'tasks': tasks_info
    }
    
    # If requested, wait for task completion
    if wait_for_completion:
        result['completion_status'] = wait_for_tasks_completion(
            cluster=ECS_CLUSTER,
            task_arns=[task.get('task_arn') for task in response.get('tasks', [])]
        )
    
    return result


def wait_for_tasks_completion(cluster: str, task_arns: List[str], timeout: int = 600) -> Dict[str, Any]:
    """
    Wait for ECS tasks to complete.
    
    Args:
        cluster: ECS cluster name
        task_arns: List of task ARNs to monitor
        timeout: Maximum time to wait in seconds
    
    Returns:
        Status information
    """
    import time
    
    start_time = time.time()
    
    while time.time() - start_time < timeout:
        response = ecs_client.describe_tasks(
            cluster=cluster,
            tasks=task_arns
        )
        
        all_stopped = True
        for task in response.get('tasks', []):
            if task.get('lastStatus') not in ['STOPPED', 'STOPPING']:
                all_stopped = False
                break
        
        if all_stopped:
            return {
                'completed': True,
                'status': 'All tasks completed'
            }
        
        time.sleep(10)
    
    return {
        'completed': False,
        'status': f'Timeout waiting for tasks (waited {timeout}s)'
    }


def describe_tasks(cluster: str, task_arns: List[str]) -> List[Dict[str, Any]]:
    """
    Get details about ECS tasks.
    
    Args:
        cluster: ECS cluster name
        task_arns: List of task ARNs
    
    Returns:
        Task details
    """
    response = ecs_client.describe_tasks(
        cluster=cluster,
        tasks=task_arns
    )
    
    tasks_details = []
    for task in response.get('tasks', []):
        tasks_details.append({
            'task_arn': task.get('taskArn'),
            'status': task.get('lastStatus'),
            'desired_status': task.get('desiredStatus'),
            'created_at': task.get('createdAt').isoformat() if task.get('createdAt') else None,
            'exit_code': task.get('containers', [{}])[0].get('exitCode')
        })
    
    return tasks_details


def get_task_logs(cluster: str, task_arn: str, log_group: str, prefix: str = 'ecs') -> Optional[List[str]]:
    """
    Retrieve CloudWatch logs for a specific task.
    
    Args:
        cluster: ECS cluster name
        task_arn: Task ARN
        log_group: CloudWatch log group name
        prefix: Log stream prefix
    
    Returns:
        List of log messages
    """
    try:
        logs_client = boto3.client('logs')
        
        # Extract task ID from ARN
        task_id = task_arn.split('/')[-1]
        log_stream = f"{prefix}/{ECS_TASK_DEFINITION}/{task_id}"
        
        response = logs_client.get_log_events(
            logGroupName=log_group,
            logStreamName=log_stream
        )
        
        return [event['message'] for event in response.get('events', [])]
    
    except Exception as e:
        print(f"Error retrieving task logs: {str(e)}")
        return None
