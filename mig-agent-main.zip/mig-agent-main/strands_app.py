"""
Example Strands framework application for running in ECS Fargate.
This application demonstrates how to integrate with Bedrock agents.
"""

import os
import json
import logging
import boto3
import asyncio
from typing import Dict, Any, Optional
from dataclasses import dataclass
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize AWS clients
bedrock_client = boto3.client('bedrock-agent-runtime')
bedrock_agent_client = boto3.client('bedrock-agent')

# Environment variables
AGENT_ID = os.environ.get('BEDROCK_AGENT_ID', '')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')


@dataclass
class StrandsTask:
    """Represents a task in the Strands framework"""
    task_id: str
    task_name: str
    description: str
    input_data: Dict[str, Any]
    status: str = "PENDING"
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    created_at: datetime = None
    completed_at: Optional[datetime] = None
    
    def __post_init__(self):
        if self.created_at is None:
            self.created_at = datetime.utcnow()


class StrandsAgent:
    """
    Wrapper for Bedrock agents using Strands framework.
    Manages agent interactions and task execution.
    """
    
    def __init__(self, agent_id: str = None):
        """
        Initialize the Strands agent.
        
        Args:
            agent_id: The ID of the Bedrock agent to use
        """
        self.agent_id = agent_id or AGENT_ID
        self.session_id = self._generate_session_id()
        self.tasks: Dict[str, StrandsTask] = {}
        
        if not self.agent_id:
            raise ValueError("Agent ID must be provided or set via BEDROCK_AGENT_ID")
        
        logger.info(f"Initialized Strands agent: {self.agent_id}, Session: {self.session_id}")
    
    @staticmethod
    def _generate_session_id() -> str:
        """Generate a unique session ID"""
        import uuid
        return str(uuid.uuid4())
    
    async def execute_task(self, task: StrandsTask) -> StrandsTask:
        """
        Execute a task using the Bedrock agent.
        
        Args:
            task: The task to execute
        
        Returns:
            Updated task with results
        """
        try:
            logger.info(f"Executing task: {task.task_id} - {task.task_name}")
            task.status = "RUNNING"
            
            # Prepare the prompt for the agent
            prompt = self._prepare_prompt(task)
            
            # Invoke the agent
            response = await self._invoke_agent(prompt)
            
            # Process the response
            task.result = response
            task.status = "COMPLETED"
            task.completed_at = datetime.utcnow()
            
            logger.info(f"Task completed: {task.task_id}")
        
        except Exception as e:
            logger.error(f"Error executing task {task.task_id}: {str(e)}")
            task.status = "FAILED"
            task.error = str(e)
            task.completed_at = datetime.utcnow()
        
        self.tasks[task.task_id] = task
        return task
    
    async def execute_tasks(self, tasks: list) -> Dict[str, StrandsTask]:
        """
        Execute multiple tasks concurrently.
        
        Args:
            tasks: List of StrandsTask objects
        
        Returns:
            Dictionary of executed tasks
        """
        task_list = tasks if isinstance(tasks, list) else [tasks]
        
        # Execute tasks concurrently
        results = await asyncio.gather(
            *[self.execute_task(task) for task in task_list],
            return_exceptions=True
        )
        
        return {task.task_id: task for task in results if isinstance(task, StrandsTask)}
    
    def _prepare_prompt(self, task: StrandsTask) -> str:
        """
        Prepare a prompt for the agent based on the task.
        
        Args:
            task: The task to prepare the prompt for
        
        Returns:
            A formatted prompt string
        """
        input_text = json.dumps(task.input_data) if task.input_data else ""
        
        prompt = f"""
Task: {task.task_name}
Description: {task.description}
Input Data: {input_text}

Please analyze this task and provide a comprehensive response.
"""
        return prompt.strip()
    
    async def _invoke_agent(self, user_input: str) -> Dict[str, Any]:
        """
        Invoke the Bedrock agent with the given input.
        
        Args:
            user_input: The input to send to the agent
        
        Returns:
            The agent's response
        """
        try:
            # Use synchronous client in async context
            loop = asyncio.get_event_loop()
            
            response = await loop.run_in_executor(
                None,
                lambda: bedrock_client.invoke_agent(
                    agentId=self.agent_id,
                    sessionId=self.session_id,
                    inputText=user_input
                )
            )
            
            # Process the response stream
            output_text = self._process_response_stream(response)
            
            return {
                'agent_response': output_text,
                'response_type': response.get('contentType', 'text/plain'),
                'timestamp': datetime.utcnow().isoformat()
            }
        
        except Exception as e:
            logger.error(f"Error invoking agent: {str(e)}")
            raise
    
    @staticmethod
    def _process_response_stream(response: Dict[str, Any]) -> str:
        """
        Process the agent response stream.
        
        Args:
            response: The response from invoke_agent
        
        Returns:
            Concatenated text from the stream
        """
        output_text = ""
        
        if 'body' in response:
            for event in response['body']:
                if 'chunk' in event:
                    chunk = event['chunk']
                    if 'bytes' in chunk:
                        output_text += chunk['bytes'].decode('utf-8')
        
        return output_text
    
    def get_task_status(self, task_id: str) -> Optional[StrandsTask]:
        """Get the status of a task"""
        return self.tasks.get(task_id)
    
    def get_all_tasks(self) -> Dict[str, StrandsTask]:
        """Get all executed tasks"""
        return self.tasks


async def main():
    """Main entry point for the application"""
    
    logger.info("Starting Strands Framework Application")
    
    try:
        # Initialize the agent
        agent = StrandsAgent(AGENT_ID)
        
        # Create sample tasks
        tasks = [
            StrandsTask(
                task_id="task-001",
                task_name="Data Analysis",
                description="Analyze the provided dataset",
                input_data={
                    "dataset": "sales_data",
                    "period": "2024-Q1",
                    "metrics": ["revenue", "growth", "forecast"]
                }
            ),
            StrandsTask(
                task_id="task-002",
                task_name="Report Generation",
                description="Generate a comprehensive report",
                input_data={
                    "report_type": "executive_summary",
                    "format": "pdf",
                    "include_charts": True
                }
            )
        ]
        
        # Execute tasks
        logger.info("Executing tasks...")
        results = await agent.execute_tasks(tasks)
        
        # Log results
        for task_id, task in results.items():
            logger.info(f"Task {task_id}: {task.status}")
            if task.result:
                logger.info(f"Result: {json.dumps(task.result, indent=2)}")
            if task.error:
                logger.error(f"Error: {task.error}")
        
        logger.info("Application completed successfully")
        return results
    
    except Exception as e:
        logger.error(f"Application error: {str(e)}", exc_info=True)
        raise


if __name__ == "__main__":
    # Run the async main function
    results = asyncio.run(main())
    
    # Exit with appropriate status
    exit(0 if results else 1)
