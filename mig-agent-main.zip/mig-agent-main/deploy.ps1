# Deployment script for Bedrock Agent infrastructure (Windows PowerShell)

$ErrorActionPreference = "Stop"

# Colors for output
$GREEN = "`e[32m"
$YELLOW = "`e[33m"
$RED = "`e[31m"
$RESET = "`e[0m"

Write-Host "${GREEN}=== Bedrock Agent Deployment Script ===${RESET}`n"

# Check prerequisites
Write-Host "Checking prerequisites..."

$missingTools = @()

if (-not (Get-Command terraform -ErrorAction SilentlyContinue)) {
    $missingTools += "Terraform"
}

if (-not (Get-Command aws -ErrorAction SilentlyContinue)) {
    $missingTools += "AWS CLI"
}

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    $missingTools += "Docker"
}

if ($missingTools.Count -gt 0) {
    Write-Host "${RED}Missing tools: $($missingTools -join ', ')${RESET}"
    exit 1
}

Write-Host "${GREEN}✓ All prerequisites installed${RESET}`n"

# Get AWS account ID
$ACCOUNT_ID = aws sts get-caller-identity --query Account --output text
$AWS_REGION = $env:AWS_REGION -or "us-east-1"
$PROJECT_NAME = $env:PROJECT_NAME -or "bedrock-agent"
$ENVIRONMENT = $env:ENVIRONMENT -or "dev"
$ECR_REPOSITORY = $PROJECT_NAME

Write-Host "AWS Account ID: $ACCOUNT_ID"
Write-Host "AWS Region: $AWS_REGION"
Write-Host "Project Name: $PROJECT_NAME"
Write-Host "Environment: $ENVIRONMENT"
Write-Host ""

# Step 1: Build and push Docker image
Write-Host "${YELLOW}Step 1: Building and pushing Docker image${RESET}"

# Create ECR repository if it doesn't exist
$repoExists = aws ecr describe-repositories `
    --repository-names $ECR_REPOSITORY `
    --region $AWS_REGION `
    --error-action SilentlyContinue 2>$null

if (-not $repoExists) {
    Write-Host "Creating ECR repository: $ECR_REPOSITORY"
    aws ecr create-repository `
        --repository-name $ECR_REPOSITORY `
        --region $AWS_REGION `
        --tags Key=Project,Value=$PROJECT_NAME | Out-Null
}

# Login to ECR
Write-Host "Logging in to ECR..."
$loginPassword = aws ecr get-login-password --region $AWS_REGION
$loginPassword | docker login --username AWS --password-stdin "$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com" | Out-Null

# Build image
Write-Host "Building Docker image..."
docker build -t "$ECR_REPOSITORY:latest" . | Out-Null

# Push image
$ECR_URI = "$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com/$ECR_REPOSITORY:latest"
Write-Host "Pushing image to $ECR_URI..."
docker tag "$ECR_REPOSITORY:latest" "$ECR_URI"
docker push "$ECR_URI" | Out-Null

Write-Host "${GREEN}✓ Docker image built and pushed${RESET}`n"

# Step 2: Package Lambda functions
Write-Host "${YELLOW}Step 2: Packaging Lambda functions${RESET}"

# Package agent invoker
if (Test-Path "lambda_agent_invoker") {
    Remove-Item -Recurse -Force "lambda_agent_invoker"
}
New-Item -ItemType Directory -Name "lambda_agent_invoker" | Out-Null
Copy-Item "lambda_agent_invoker.py" "lambda_agent_invoker\index.py"

Push-Location "lambda_agent_invoker"
7z a "..\lambda_agent_invoker.zip" "." | Out-Null
Pop-Location

Remove-Item -Recurse -Force "lambda_agent_invoker"

# Package task runner
if (Test-Path "lambda_task_runner") {
    Remove-Item -Recurse -Force "lambda_task_runner"
}
New-Item -ItemType Directory -Name "lambda_task_runner" | Out-Null
Copy-Item "lambda_task_runner.py" "lambda_task_runner\index.py"

Push-Location "lambda_task_runner"
7z a "..\lambda_task_runner.zip" "." | Out-Null
Pop-Location

Remove-Item -Recurse -Force "lambda_task_runner"

Write-Host "${GREEN}✓ Lambda functions packaged${RESET}`n"

# Step 3: Update terraform.tfvars
Write-Host "${YELLOW}Step 3: Updating terraform.tfvars${RESET}"

@"
aws_region        = "$AWS_REGION"
project_name      = "$PROJECT_NAME"
environment       = "$ENVIRONMENT"

# ECR Image URI
container_image_uri = "$ECR_URI"

# Bedrock configuration
bedrock_agent_name              = "strands-agent"
bedrock_foundational_model      = "anthropic.claude-3-sonnet-20240229-v1:0"

# Resource sizing
container_cpu     = 512
container_memory  = 1024
ecs_desired_count = 2

# Networking
vpc_cidr              = "10.0.0.0/16"
public_subnet_cidrs   = ["10.0.101.0/24", "10.0.102.0/24"]
private_subnet_cidrs  = ["10.0.1.0/24", "10.0.2.0/24"]
enable_nat_gateway    = true

# Lambda
lambda_timeout = 300
lambda_memory  = 512
"@ | Out-File -FilePath "terraform.tfvars" -Encoding UTF8

Write-Host "${GREEN}✓ terraform.tfvars updated${RESET}`n"

# Step 4: Terraform operations
Write-Host "${YELLOW}Step 4: Running Terraform${RESET}"

# Initialize
Write-Host "Initializing Terraform..."
terraform init | Out-Null

# Validate
Write-Host "Validating configuration..."
terraform validate | Out-Null

# Plan
Write-Host "Creating Terraform plan..."
terraform plan -out=tfplan | Out-Null

# Ask for confirmation
Write-Host ""
$confirmation = Read-Host "Do you want to apply this plan? (yes/no)"
if ($confirmation -ne "yes") {
    Write-Host "Deployment cancelled"
    exit 0
}

# Apply
Write-Host "Applying Terraform configuration..."
terraform apply tfplan
Remove-Item "tfplan"

Write-Host "${GREEN}✓ Infrastructure deployed${RESET}`n"

# Step 5: Display outputs
Write-Host "${YELLOW}Step 5: Deployment Summary${RESET}"
Write-Host ""
Write-Host "Deployment completed successfully!"
Write-Host ""
Write-Host "Outputs:"
terraform output

Write-Host ""
Write-Host "${GREEN}=== Deployment Complete ===${RESET}"
Write-Host ""
Write-Host "Next steps:"

$clusterName = terraform output -raw ecs_cluster_name
$serviceName = terraform output -raw ecs_service_name
$apiEndpoint = terraform output -raw api_gateway_endpoint

Write-Host "1. Monitor ECS service: aws ecs describe-services --cluster $clusterName --services $serviceName"
Write-Host "2. Test API: curl $apiEndpoint/invoke-agent"
Write-Host "3. View logs: aws logs tail /ecs/$clusterName --follow"
