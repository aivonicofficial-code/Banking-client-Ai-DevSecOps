output "alb_dns_name" {
  value       = aws_lb.main.dns_name
  description = "DNS name of the load balancer"
}

output "ecs_cluster_name" {
  value       = aws_ecs_cluster.main.name
  description = "Name of the ECS cluster"
}

output "ecs_service_name" {
  value       = aws_ecs_service.main.name
  description = "Name of the ECS service"
}

output "api_gateway_endpoint" {
  value       = "${aws_apigatewayv2_api.main.api_endpoint}/${aws_apigatewayv2_stage.main.name}"
  description = "API Gateway endpoint URL"
}

output "lambda_agent_invoker_function_name" {
  value       = aws_lambda_function.agent_invoker.function_name
  description = "Name of the Lambda function for invoking agents"
}

output "lambda_task_runner_function_name" {
  value       = aws_lambda_function.task_runner.function_name
  description = "Name of the Lambda function for running ECS tasks"
}

output "bedrock_agent_id" {
  value       = aws_bedrockagent_agent.main.agent_id
  description = "ID of the Bedrock agent"
}

output "bedrock_agent_arn" {
  value       = aws_bedrockagent_agent.main.agent_arn
  description = "ARN of the Bedrock agent"
}

output "ecr_repository_url" {
  value       = aws_ecr_repository.bedrock_agent.repository_url
  description = "URL of the ECR repository"
}

output "ecr_repository_arn" {
  value       = aws_ecr_repository.bedrock_agent.arn
  description = "ARN of the ECR repository"
}

output "vpc_id" {
  value       = aws_vpc.main.id
  description = "ID of the VPC"
}

output "private_subnet_ids" {
  value       = aws_subnet.private[*].id
  description = "IDs of the private subnets"
}

output "public_subnet_ids" {
  value       = aws_subnet.public[*].id
  description = "IDs of the public subnets"
}
