"""
Lambda function to invoke Bedrock agents using Strands framework.
This function accepts requests to invoke agents and manages agent interactions.
"""

import json
import boto3
import os
from typing import Dict, Any, List, Optional

bedrock_client = boto3.client('bedrock-agent-runtime')
bedrock_agent_client = boto3.client('bedrock-agent')

AGENT_ID = os.environ.get('BEDROCK_AGENT_ID')
AWS_REGION = os.environ.get('AWS_REGION', 'us-east-1')


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda handler for invoking Bedrock agents.
    
    Expected event structure:
    {
        "body": {
            "agent_id": "string (optional, uses default AGENT_ID if not provided)",
            "session_id": "string (unique session identifier)",
            "user_input": "string (user's input/prompt)",
            "max_tokens": "number (optional)",
            "inference_config": "object (optional)"
        }
    }
    """
    try:
        # Parse request body
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Validate required fields
        user_input = body.get('user_input')
        session_id = body.get('session_id')
        
        if not user_input or not session_id:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'Missing required fields: user_input and session_id'
                })
            }
        
        agent_id = body.get('agent_id', AGENT_ID)
        
        if not agent_id:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'No agent ID provided and BEDROCK_AGENT_ID not set'
                })
            }
        
        # Invoke the agent
        response = invoke_agent(
            agent_id=agent_id,
            session_id=session_id,
            user_input=user_input,
            max_tokens=body.get('max_tokens', 2048),
            inference_config=body.get('inference_config')
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps(response)
        }
    
    except Exception as e:
        print(f"Error invoking agent: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': f'Failed to invoke agent: {str(e)}'
            })
        }


def invoke_agent(
    agent_id: str,
    session_id: str,
    user_input: str,
    max_tokens: int = 2048,
    inference_config: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Invoke a Bedrock agent with the given input.
    
    Args:
        agent_id: The ID of the agent to invoke
        session_id: Unique session identifier for maintaining context
        user_input: The user's input/prompt
        max_tokens: Maximum tokens for the response
        inference_config: Optional inference configuration
    
    Returns:
        Response from the agent
    """
    
    # Prepare the request parameters
    request_params = {
        'agentId': agent_id,
        'sessionId': session_id,
        'inputText': user_input,
    }
    
    # Add optional parameters
    if inference_config:
        request_params['inferenceConfig'] = inference_config
    
    # Invoke the agent
    response = bedrock_client.invoke_agent(**request_params)
    
    # Process the response stream
    result = {
        'agent_id': agent_id,
        'session_id': session_id,
        'response_type': response.get('contentType', 'text/plain'),
        'output': process_agent_response(response)
    }
    
    return result


def process_agent_response(response: Dict[str, Any]) -> str:
    """
    Process the agent response stream and extract the text content.
    
    Args:
        response: The response from invoke_agent
    
    Returns:
        Concatenated text from the response stream
    """
    output_text = ""
    
    # Process the event stream
    if 'body' in response:
        for event in response['body']:
            if 'chunk' in event:
                chunk = event['chunk']
                if 'bytes' in chunk:
                    output_text += chunk['bytes'].decode('utf-8')
    
    return output_text


def get_agent_details(agent_id: str) -> Dict[str, Any]:
    """
    Get details about a specific agent.
    
    Args:
        agent_id: The ID of the agent
    
    Returns:
        Agent details
    """
    try:
        response = bedrock_agent_client.get_agent(agentId=agent_id)
        return {
            'agent_id': response.get('agentId'),
            'agent_name': response.get('agentName'),
            'agent_status': response.get('agentStatus'),
            'description': response.get('description'),
            'foundation_model': response.get('foundationModel')
        }
    except Exception as e:
        print(f"Error getting agent details: {str(e)}")
        return {}


def list_agents() -> List[Dict[str, str]]:
    """
    List all available agents.
    
    Returns:
        List of agent information
    """
    try:
        response = bedrock_agent_client.list_agents()
        agents = []
        
        for agent_summary in response.get('agentSummaries', []):
            agents.append({
                'agent_id': agent_summary.get('agentId'),
                'agent_name': agent_summary.get('agentName'),
                'agent_status': agent_summary.get('agentStatus')
            })
        
        return agents
    except Exception as e:
        print(f"Error listing agents: {str(e)}")
        return []
