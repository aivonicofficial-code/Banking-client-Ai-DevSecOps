# Bedrock Agent on AWS with ECS Fargate and Lambda

This Terraform configuration sets up a complete infrastructure for running Bedrock agents with ECS Fargate and Lambda integration using the Strands framework.

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                          AWS Architecture                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │                    API Gateway                            │   │
│  │              (HTTP endpoint for agents)                  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                            ↓                                      │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │    Lambda Functions                                       │   │
│  │  ┌─────────────────────┐  ┌─────────────────────┐       │   │
│  │  │ Agent Invoker       │  │ Task Runner         │       │   │
│  │  │ (Invoke Agents)     │  │ (Run ECS Tasks)     │       │   │
│  │  └─────────────────────┘  └─────────────────────┘       │   │
│  └──────────────────────────────────────────────────────────┘   │
│            ↓                          ↓                           │
│  ┌──────────────────────┐  ┌──────────────────────────────────┐  │
│  │  Bedrock Agent       │  │     ECS Fargate Cluster          │  │
│  │                      │  │  ┌──────────────────────────┐    │  │
│  │  ┌────────────────┐  │  │  │   ECS Service            │    │  │
│  │  │ Foundational   │  │  │  │ (Strands Application)    │    │  │
│  │  │ Model (Claude) │  │  │  │                          │    │  │
│  │  └────────────────┘  │  │  │ ┌────────────────────┐  │    │  │
│  │                      │  │  │ │ Task 1             │  │    │  │
│  └──────────────────────┘  │  │ └────────────────────┘  │    │  │
│                            │  │ ┌────────────────────┐  │    │  │
│                            │  │ │ Task 2             │  │    │  │
│                            │  │ └────────────────────┘  │    │  │
│                            │  └──────────────────────────┘    │  │
│                            └──────────────────────────────────┘  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

## Components

### 1. **Bedrock Agent**
- AWS Bedrock agent powered by Claude foundation model
- Handles intelligent request processing and decision-making
- Manages conversation context through session IDs

### 2. **ECS Fargate**
- Serverless container orchestration
- Runs the Strands framework application
- Auto-scaling based on CPU and memory metrics
- Multi-AZ deployment for high availability

### 3. **Lambda Functions**
- **Agent Invoker**: Calls Bedrock agents via API Gateway
- **Task Runner**: Spawns ECS tasks for long-running operations
- Integrates with VPC for secure communication

### 4. **Networking**
- VPC with public and private subnets
- NAT Gateway for secure outbound connections
- Security groups for traffic control
- Application Load Balancer for ECS service

## Prerequisites

- AWS account with appropriate permissions
- Terraform >= 1.0
- AWS CLI configured
- Docker (for building container images)
- ECR repository for storing container images

## Files Structure

```
mig-agent/
├── main.tf                      # Main configuration
├── variables.tf                 # Input variables
├── outputs.tf                   # Output values
├── networking.tf                # VPC and network resources
├── iam.tf                       # IAM roles and policies
├── bedrock.tf                   # Bedrock agent configuration
├── ecs.tf                       # ECS cluster and service
├── lambda.tf                    # Lambda functions and API Gateway
├── strands_app.py               # Example Strands application
├── lambda_agent_invoker.py      # Lambda function for agent invocation
├── lambda_task_runner.py        # Lambda function for ECS task execution
├── Dockerfile                   # Container image definition
├── requirements.txt             # Python dependencies
└── terraform.tfvars             # Variable values (customize this)
```

## Deployment Steps

### 1. Prepare Docker Image

```bash
# Build Docker image
docker build -t bedrock-agent:latest .

# Create ECR repository
aws ecr create-repository --repository-name bedrock-agent --region us-east-1

# Get login token
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com

# Tag and push image
docker tag bedrock-agent:latest <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest
docker push <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest
```

### 2. Prepare Lambda Functions

```bash
# Create deployment packages
cd mig-agent

# Package agent invoker
mkdir -p lambda_agent_invoker
cp lambda_agent_invoker.py lambda_agent_invoker/index.py
cd lambda_agent_invoker
zip -r ../lambda_agent_invoker.zip .
cd ..

# Package task runner
mkdir -p lambda_task_runner
cp lambda_task_runner.py lambda_task_runner/index.py
cd lambda_task_runner
zip -r ../lambda_task_runner.zip .
cd ..
```

### 3. Configure Terraform Variables

Update `terraform.tfvars` with your values:

```hcl
aws_region        = "us-east-1"
project_name      = "bedrock-agent"
environment       = "dev"

# Update with your ECR image URI
container_image_uri = "123456789.dkr.ecr.us-east-1.amazonaws.com/bedrock-agent:latest"

# Bedrock configuration
bedrock_agent_name              = "strands-agent"
bedrock_foundational_model      = "anthropic.claude-3-sonnet-20240229-v1:0"

# Resource sizing
container_cpu     = 512
container_memory  = 1024
ecs_desired_count = 2

# Networking
vpc_cidr              = "10.0.0.0/16"
enable_nat_gateway    = true
```

### 4. Deploy with Terraform

```bash
# Initialize Terraform
terraform init

# Validate configuration
terraform validate

# Plan deployment
terraform plan -out=tfplan

# Apply configuration
terraform apply tfplan
```

## Usage Examples

### Invoke Agent via API Gateway

```bash
# Get API endpoint
API_ENDPOINT=$(terraform output -raw api_gateway_endpoint)

# Invoke agent
curl -X POST $API_ENDPOINT/invoke-agent \
  -H "Content-Type: application/json" \
  -d '{
    "session_id": "session-123",
    "user_input": "Analyze the quarterly sales data",
    "max_tokens": 2048
  }'
```

### Response Example

```json
{
  "agent_id": "agent-xyz123",
  "session_id": "session-123",
  "response_type": "text/plain",
  "output": "Based on the quarterly sales data analysis, I can provide the following insights..."
}
```

### Run ECS Task via Lambda

```bash
# Get Lambda function name
LAMBDA_FUNCTION=$(terraform output -raw lambda_task_runner_function_name)

# Invoke task runner
aws lambda invoke \
  --function-name $LAMBDA_FUNCTION \
  --payload '{
    "body": {
      "task_command": ["python", "app.py", "--mode", "analyze"],
      "environment_vars": {
        "ANALYSIS_TYPE": "detailed",
        "OUTPUT_FORMAT": "json"
      }
    }
  }' \
  response.json

cat response.json
```

## Monitoring and Logging

### CloudWatch Logs

Access logs for different components:

```bash
# ECS logs
aws logs tail /ecs/bedrock-agent-dev --follow

# Lambda logs
aws logs tail /aws/lambda/bedrock-agent-dev-agent-invoker --follow
aws logs tail /aws/lambda/bedrock-agent-dev-task-runner --follow

# API Gateway logs
aws logs tail /aws/apigateway/bedrock-agent-dev --follow
```

### CloudWatch Metrics

View metrics in AWS Console:
- ECS Service: CPU/Memory utilization, Task count
- Lambda: Invocations, Duration, Errors
- API Gateway: Request count, Latency

## Auto-Scaling

The ECS service includes auto-scaling policies:

- **CPU-based scaling**: Target 70% average CPU utilization
- **Memory-based scaling**: Target 80% average memory utilization
- **Scale range**: 2 to 4 tasks

## Security Best Practices

1. **IAM Roles**: Least privilege access principle
2. **VPC**: Private subnets for ECS tasks, NAT Gateway for outbound
3. **Security Groups**: Restrictive ingress rules
4. **Bedrock**: Agent role limited to foundation model invocation
5. **Secrets**: Use AWS Secrets Manager for sensitive data

## Cost Optimization

1. **ECS**: Fargate Spot for development/testing
2. **Data Transfer**: Use VPC endpoints to reduce NAT costs
3. **CloudWatch**: Adjust log retention as needed
4. **Bedrock**: Monitor token usage and optimize prompts

## Troubleshooting

### ECS Task Won't Start

```bash
# Check task definition
aws ecs describe-task-definition --task-definition bedrock-agent-dev

# Check service events
aws ecs describe-services --cluster bedrock-agent-dev-cluster --services bedrock-agent-dev
```

### Lambda Timeout Issues

Increase timeout in `terraform.tfvars`:
```hcl
lambda_timeout = 600  # 10 minutes
```

### Bedrock Agent Errors

```bash
# Check agent status
aws bedrock-agent get-agent --agent-id <AGENT_ID>

# View agent resource configuration
aws bedrock-agent get-agent-resource --agent-id <AGENT_ID>
```

## Cleanup

```bash
# Destroy all resources
terraform destroy

# Remove ECR repository
aws ecr delete-repository --repository-name bedrock-agent --force --region us-east-1
```

## References

- [AWS Bedrock Documentation](https://docs.aws.amazon.com/bedrock/)
- [ECS Fargate Documentation](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/launch_types.html)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- [Strands Framework](https://www.anthropic.com/research/towards-general-purpose-agents)

## Support

For issues or questions, refer to AWS documentation or create an issue in your repository.
