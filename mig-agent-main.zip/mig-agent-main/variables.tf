variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "project_name" {
  description = "Project name"
  type        = string
  default     = "bedrock-agent"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "container_image_uri" {
  description = "Docker image URI for ECS task"
  type        = string
}

variable "container_cpu" {
  description = "CPU units for ECS task (256-4096)"
  type        = number
  default     = 512
}

variable "container_memory" {
  description = "Memory for ECS task in MB (512-30720)"
  type        = number
  default     = 1024
}

variable "ecs_desired_count" {
  description = "Desired number of ECS tasks"
  type        = number
  default     = 2
}

variable "bedrock_agent_name" {
  description = "Name of the Bedrock agent"
  type        = string
  default     = "strands-agent"
}

variable "bedrock_foundational_model" {
  description = "Model to use for Bedrock agent"
  type        = string
  default     = "anthropic.claude-3-sonnet-20240229-v1:0"
}

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets"
  type        = list(string)
  default     = ["10.0.101.0/24", "10.0.102.0/24"]
}

variable "enable_nat_gateway" {
  description = "Enable NAT Gateway for private subnets"
  type        = bool
  default     = true
}

variable "agent_description" {
  description = "Description of the Bedrock agent"
  type        = string
  default     = "Strands-based agent for autonomous task execution"
}

variable "agent_instruction" {
  description = "Instruction for the Bedrock agent"
  type        = string
  default     = "You are an autonomous AI agent powered by Strands framework. Your role is to execute complex tasks by breaking them down into manageable steps, coordinating with various tools and services, and providing intelligent responses. You have access to ECS Fargate for running containerized tasks, Lambda functions for serverless execution, and various AWS services. Always think step-by-step, be thorough in your analysis, and provide clear explanations of your actions and decisions."
}

variable "lambda_timeout" {
  description = "Lambda function timeout in seconds"
  type        = number
  default     = 300
}

variable "lambda_memory" {
  description = "Lambda function memory in MB"
  type        = number
  default     = 512
}
