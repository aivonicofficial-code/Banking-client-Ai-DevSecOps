# Troubleshooting and FAQ

## Frequently Asked Questions

### General Questions

**Q: What AWS region should I deploy to?**
A: The default is `us-east-1`. Update `terraform.tfvars` for other regions, but ensure Bedrock is available in your chosen region. Check: `aws bedrock list-foundation-models --region <region>`

**Q: How much will this cost?**
A: Estimated $60-150/month for development (2 tasks). See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed cost breakdown.

**Q: Can I run this on Windows?**
A: Yes! Use `deploy.ps1` for Windows PowerShell deployment automation.

**Q: How do I customize the Bedrock model?**
A: Update `bedrock_foundational_model` in `terraform.tfvars`. Available models:
- `anthropic.claude-3-opus-20240229-v1:0` (most capable)
- `anthropic.claude-3-sonnet-20240229-v1:0` (balanced)
- `anthropic.claude-3-haiku-20240307-v1:0` (fastest)

### Deployment Issues

**Q: Terraform init fails with provider error**
```
Error: Failed to download providers
```
Solution:
```bash
rm -rf .terraform/
terraform init -upgrade
```

**Q: ECR login fails during deployment**
```
Error: unauthorized: authentication required
```
Solution:
```bash
aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin <ACCOUNT_ID>.dkr.ecr.us-east-1.amazonaws.com
```

**Q: Docker image build fails**
```
Error: failed to solve: rpc error
```
Solution:
1. Ensure Docker daemon is running: `docker ps`
2. Check disk space: `docker system df`
3. Clean up: `docker system prune`

**Q: Lambda function deployment fails**
```
Error: InvalidRoleArn
```
Solution: Ensure IAM roles exist and have proper trust relationships:
```bash
aws iam get-role --role-name <role-name>
```

### Runtime Issues

**Q: ECS tasks fail to start**

Check task definition and service configuration:
```bash
# Get task definition
aws ecs describe-task-definition \
  --task-definition bedrock-agent-dev

# Check service events
aws ecs describe-services \
  --cluster bedrock-agent-dev-cluster \
  --services bedrock-agent-dev

# View task logs
aws logs tail /ecs/bedrock-agent-dev --follow
```

**Q: Lambda timeout when calling Bedrock**

Increase timeout in `terraform.tfvars`:
```hcl
lambda_timeout = 600  # 10 minutes
```

Or increase in AWS Console:
```bash
aws lambda update-function-configuration \
  --function-name bedrock-agent-dev-agent-invoker \
  --timeout 600
```

**Q: API Gateway returns 502 Bad Gateway**

Common causes:
1. Lambda function error: Check CloudWatch logs
2. VPC networking: Verify security groups
3. Lambda timeout: Increase timeout value

Debug:
```bash
aws logs tail /aws/apigateway/bedrock-agent-dev --follow
aws logs tail /aws/lambda/bedrock-agent-dev-agent-invoker --follow
```

### Performance Issues

**Q: Slow response times from Bedrock**

1. Check Bedrock metrics in CloudWatch
2. Review token usage patterns
3. Optimize prompts for conciseness
4. Consider batch processing for large tasks

**Q: ECS tasks not auto-scaling**

Check auto-scaling configuration:
```bash
aws application-autoscaling describe-scaling-targets \
  --service-namespace ecs \
  --resource-id service/bedrock-agent-dev-cluster/bedrock-agent-dev

aws application-autoscaling describe-scaling-policies \
  --service-namespace ecs
```

**Q: High Lambda invocation latency**

1. Ensure Lambda has sufficient memory (default: 512 MB)
2. Check VPC cold start issues
3. Consider Lambda provisioned concurrency

### Networking Issues

**Q: Cannot access API Gateway endpoint**

1. Check API Gateway stage:
```bash
aws apigatewayv2 get-stages --api-id <API_ID>
```

2. Verify security group allows traffic:
```bash
aws ec2 describe-security-groups --group-ids <sg-id>
```

3. Test with curl:
```bash
curl -v https://<api-id>.execute-api.us-east-1.amazonaws.com/dev/invoke-agent
```

**Q: Lambda in VPC cannot reach Bedrock**

1. Check NAT Gateway:
```bash
aws ec2 describe-nat-gateways --filter "Name=subnet-id,Values=<subnet-id>"
```

2. Verify route tables:
```bash
aws ec2 describe-route-tables --filters "Name=vpc-id,Values=<vpc-id>"
```

3. Check security group egress rules:
```bash
aws ec2 describe-security-groups --group-ids <sg-id>
```

### Cost Issues

**Q: Unexpected high charges**

1. Check CloudWatch metrics:
```bash
aws cloudwatch get-metric-statistics \
  --namespace AWS/Lambda \
  --metric-name Invocations \
  --start-time 2024-01-01T00:00:00Z \
  --end-time 2024-01-31T23:59:59Z \
  --period 86400 \
  --statistics Sum
```

2. Review Bedrock usage:
```bash
# Check CloudWatch metrics for Bedrock
aws cloudwatch get-metric-statistics \
  --namespace AWS/Bedrock \
  --metric-name ModelInvocations
```

3. Optimize:
- Reduce task count
- Use Fargate Spot
- Reduce Lambda memory if not needed
- Implement caching

## Troubleshooting Checklist

### Before Deployment
- [ ] AWS credentials configured: `aws sts get-caller-identity`
- [ ] Terraform installed: `terraform version`
- [ ] Docker running: `docker ps`
- [ ] Bedrock available: `aws bedrock list-foundation-models`
- [ ] ECR repository created (script does this)

### During Deployment
- [ ] Docker image builds successfully
- [ ] Lambda packages created
- [ ] Terraform plan reviews as expected
- [ ] All resources created successfully

### After Deployment
- [ ] ECS tasks are running
- [ ] Lambda functions are active
- [ ] API Gateway responding
- [ ] CloudWatch logs showing activity

### Testing
- [ ] API can be invoked from CLI
- [ ] Agent returns expected responses
- [ ] ECS tasks execute properly
- [ ] Logs appear in CloudWatch

## Common Error Messages

### "AccessDeniedException"
**Cause**: IAM permission issue
**Solution**: Review IAM policies in `iam.tf`, ensure roles have required permissions

### "ThrottlingException"
**Cause**: Bedrock rate limiting
**Solution**: Implement exponential backoff, request quota increase, or batch requests

### "ECSTaskFailedToStart"
**Cause**: Memory/CPU insufficient or image not found
**Solution**: Check ECR image URI, increase task resources, verify image exists

### "InvalidParameterException"
**Cause**: Invalid agent ID or session ID format
**Solution**: Verify agent ID matches Bedrock agent, use UUID format for session IDs

### "ConnectionError: Unknown"
**Cause**: VPC networking issue
**Solution**: Check NAT Gateway, route tables, security groups

## Debug Commands

### View Infrastructure Status
```bash
# ECS Cluster status
aws ecs describe-clusters --clusters bedrock-agent-dev-cluster

# Running tasks
aws ecs list-tasks --cluster bedrock-agent-dev-cluster

# Task details
aws ecs describe-tasks \
  --cluster bedrock-agent-dev-cluster \
  --tasks arn:aws:ecs:...

# Lambda function info
aws lambda get-function --function-name bedrock-agent-dev-agent-invoker

# API Gateway endpoints
aws apigatewayv2 get-apis --query 'Items[*].[ApiId,Name]'
```

### View Logs
```bash
# Real-time ECS logs
aws logs tail /ecs/bedrock-agent-dev --follow

# Real-time Lambda logs
aws logs tail /aws/lambda/bedrock-agent-dev-agent-invoker --follow

# Search for errors
aws logs filter-log-events \
  --log-group-name /ecs/bedrock-agent-dev \
  --filter-pattern "ERROR"

# Get log events
aws logs get-log-events \
  --log-group-name /ecs/bedrock-agent-dev \
  --log-stream-name ecs/bedrock-agent-dev/...
```

### Test Endpoints
```bash
# Test Lambda directly
aws lambda invoke \
  --function-name bedrock-agent-dev-agent-invoker \
  --payload '{...}' \
  response.json

# Test API Gateway
curl -X POST https://<api-id>.execute-api.us-east-1.amazonaws.com/dev/invoke-agent \
  -H "Content-Type: application/json" \
  -d '{...}'

# Test Bedrock access
aws bedrock-agent-runtime invoke-agent \
  --agent-id <agent-id> \
  --session-id test-session \
  --input-text "Test message"
```

## Performance Tuning

### Lambda Optimization
```hcl
# In lambda.tf
memory_size = 1024  # Increase for faster execution
timeout     = 600   # Increase for long-running tasks
```

### ECS Optimization
```hcl
# In ecs.tf
cpu    = 1024  # More CPU units
memory = 2048  # More memory (MB)
```

### Bedrock Optimization
```python
# In lambda_agent_invoker.py
inference_config = {
    "temperature": 0.7,  # Lower = more deterministic
    "topK": 50,
    "topP": 0.9,
    "maxTokens": 2048
}
```

## Getting Help

1. **AWS Documentation**:
   - [Bedrock Docs](https://docs.aws.amazon.com/bedrock/)
   - [ECS Docs](https://docs.aws.amazon.com/ecs/)
   - [Lambda Docs](https://docs.aws.amazon.com/lambda/)

2. **Community**:
   - AWS Forums
   - Stack Overflow (tag: amazon-bedrock)
   - GitHub Issues (this repository)

3. **Support**:
   - AWS Support Plan (Business/Enterprise)
   - CloudWatch Alarms and Notifications

## Version Information

- **Terraform**: >= 1.0
- **AWS Provider**: >= 5.0
- **Python**: 3.11
- **AWS CLI**: v2
- **Docker**: Latest

## Change Log

### v1.0.0
- Initial release
- Bedrock agent integration
- ECS Fargate deployment
- Lambda API gateway
- Complete documentation

---

Last Updated: 2024
