# GenAI ChatBot with Amazon Bedrock Agent

## Table of Contents

- [Introduction](#introduction)
- [Architecture Overview](#architecture-overview)
- [How It Works](#how-it-works)
  - [Qualitative Questions — RAG via Knowledge Base](#qualitative-questions--rag-via-knowledge-base)
  - [Quantitative Questions — Text-to-SQL via Action Group](#quantitative-questions--text-to-sql-via-action-group)
- [AWS Services Used](#aws-services-used)
- [Code Structure](#code-structure)
- [Models](#models)
- [Prerequisites](#prerequisites)
- [Deployment](#deployment)
  - [Deploy to AWS](#deploy-to-aws)
  - [Local Development](#local-development)
  - [Cleanup](#cleanup)
- [Customize with Your Own Data](#customize-with-your-own-data)
  - [Knowledge Base (Qualitative)](#knowledge-base-qualitative)
  - [Structured Data (Quantitative)](#structured-data-quantitative)

---

## Introduction

This is a GenAI chatbot that answers questions about Amazon EC2 instances — both qualitative guidance questions ("How do I launch an EC2 instance?") and quantitative pricing questions ("What is the cheapest GPU instance per hour?").

It is built on Amazon Bedrock Agents, which orchestrates between two data sources depending on the question type:

- A **Knowledge Base** backed by OpenSearch Serverless for RAG over EC2 documentation
- An **Action Group** backed by a Lambda function that converts natural language to SQL and queries EC2 pricing data via Amazon Athena

The frontend is a Streamlit app running on ECS Fargate, accessible through an Application Load Balancer.

---

## Architecture Overview

```
User
 │
 ▼
Application Load Balancer (HTTP:80)
 │
 ▼
ECS Fargate — Streamlit App (port 8501)
 │  Invokes via AWS SDK
 ▼
Lambda — Invoke Agent (invoke-lambda)
 │  Calls Bedrock Agent Runtime
 ▼
Amazon Bedrock Agent (Nova Pro foundation model)
 │
 ├──[Qualitative question]──────────────────────────────────────────────────┐
 │                                                                           │
 │                                                               Bedrock Knowledge Base
 │                                                                           │
 │                                                               OpenSearch Serverless
 │                                                               (vector index, 1536-dim)
 │                                                                           │
 │                                                               S3 — EC2 User Guide docs
 │                                                               (embedded via Titan Text v1)
 │
 └──[Quantitative question]─────────────────────────────────────────────────┐
                                                                             │
                                                              Lambda — Action Lambda
                                                              (Docker container, 3 GB RAM)
                                                                             │
                                                              LlamaIndex Text-to-SQL
                                                              (BedrockConverse + Nova Pro)
                                                                             │
                                                              Amazon Athena
                                                                             │
                                                              S3 — EC2 Pricing CSV
                                                              (catalogued by Glue Crawler)
```

---

## How It Works

### Qualitative Questions — RAG via Knowledge Base

Questions like "What is the difference between On-Demand and Reserved instances?" are routed to the Bedrock Knowledge Base.

1. The Bedrock Agent determines the question is qualitative and invokes the Knowledge Base.
2. The Knowledge Base uses **Amazon Titan Embed Text v1** to embed the query and performs a vector similarity search against the **OpenSearch Serverless** collection.
3. The collection was pre-populated by syncing the EC2 User Guide (stored as a zip in S3) through the Bedrock data source sync process.
4. Retrieved document chunks are passed back to the agent as context, and the agent synthesizes a final answer using **Amazon Nova Pro**.
5. The invoke Lambda extracts the source S3 URIs from the agent trace and resolves them to document titles and URLs, which are returned alongside the answer to the Streamlit UI.

### Quantitative Questions — Text-to-SQL via Action Group

Questions like "How much does a p3.8xlarge cost per hour?" are routed to the Action Group.

1. The Bedrock Agent determines the question is quantitative and invokes the Action Group Lambda (`/uc2` API path).
2. The **Action Lambda** receives the question and passes it to a **LlamaIndex** `SQLTableRetrieverQueryEngine`.
3. LlamaIndex uses **BedrockConverse** (Nova Pro) to generate a SQL query from the natural language input, guided by:
   - A custom SQL prompt template with EC2 instance family descriptions
   - Few-shot examples retrieved dynamically from a CSV using vector similarity (Titan Embed Text v1)
4. The generated SQL is executed against **Amazon Athena**, which queries the EC2 pricing CSV stored in S3 and catalogued by the **AWS Glue Crawler**.
5. The SQL result is passed back to LlamaIndex, which synthesizes a natural language response.
6. The Action Lambda returns the SQL query (as the source) and the answer back to the Bedrock Agent, which relays it to the user.

### Deployment Flow (Update Lambda)

On first deploy, a CloudFormation custom resource triggers the **Update Lambda**, which:

1. Runs the **Glue Crawler** to catalogue the EC2 pricing CSV into the Glue Data Catalog (making it queryable by Athena).
2. Triggers a **Bedrock Knowledge Base data source sync** to ingest and embed the EC2 User Guide documents into OpenSearch Serverless.
3. Prepares the Bedrock Agent (moves it from DRAFT to a versioned state).
4. Creates a **Bedrock Agent Alias** pointing to the latest agent version.

The **Create Index Lambda** (also a CloudFormation custom resource) creates the vector index in OpenSearch Serverless before the Knowledge Base sync runs.

---

## AWS Services Used

| Service | Role |
|---|---|
| **Amazon Bedrock Agent** | Orchestrates between Knowledge Base and Action Group based on question type. Foundation model: Amazon Nova Pro (`amazon.nova-pro-v1:0`). |
| **Amazon Bedrock Knowledge Base** | RAG pipeline over EC2 documentation. Handles qualitative questions. |
| **Amazon OpenSearch Serverless** | Vector database backing the Knowledge Base. Stores 1536-dimension embeddings with HNSW/Faiss index. |
| **Amazon Bedrock — Titan Embed Text v1** | Generates embeddings for Knowledge Base ingestion and few-shot example retrieval in the Action Lambda. |
| **Amazon Bedrock — Nova Pro** | Foundation model for the agent orchestration and text-to-SQL generation via BedrockConverse API. |
| **AWS Lambda — Action Lambda** | Container-based Lambda (3 GB RAM, 15 min timeout). Runs LlamaIndex text-to-SQL pipeline to answer quantitative questions. |
| **AWS Lambda — Invoke Lambda** | Thin Lambda invoked by the Streamlit app. Calls Bedrock Agent Runtime, parses the streaming response and traces, and returns the answer + source. |
| **AWS Lambda — Update Lambda** | CloudFormation custom resource. Runs post-deploy setup: Glue crawler, KB sync, agent preparation, alias creation. |
| **AWS Lambda — Create Index Lambda** | CloudFormation custom resource. Creates the vector index in OpenSearch Serverless before the KB sync. |
| **Amazon Athena** | Executes SQL queries generated by LlamaIndex against the EC2 pricing data. Query results are staged in S3. |
| **AWS Glue Crawler** | Crawls the EC2 pricing CSV in S3 and registers the schema in the Glue Data Catalog, making it available to Athena. |
| **AWS Glue Data Catalog** | Metadata store for the EC2 pricing table, used by Athena to resolve column names and types. |
| **Amazon S3 — Agent Assets** | Stores the EC2 User Guide zip (Knowledge Base source), the OpenAPI schema for the Action Group, and Athena query results. |
| **Amazon S3 — Athena** | Stores the EC2 pricing CSV data and Athena query result staging. |
| **Amazon ECS Fargate** | Runs the Streamlit frontend as a containerized service (ARM64, 2 vCPU / 4 GB). Auto-scales on CPU utilization. |
| **Amazon ECR** | Stores Docker images for the Streamlit app and the Action Lambda. |
| **Application Load Balancer** | Public HTTP entry point for the Streamlit app. Routes traffic to ECS tasks on port 8501. |
| **Amazon VPC** | Isolated network with public subnets (ALB, NAT Gateways) and private subnets (ECS tasks). |
| **AWS KMS** | Encrypts S3 buckets, ECR repositories, CloudWatch logs, and ECS task definitions. |
| **Amazon CloudWatch** | Collects logs from ECS tasks (30-day retention) and Lambda functions. |
| **AWS IAM** | Least-privilege roles for each Lambda, ECS task, Glue, and Bedrock Agent. |

---

## Code Structure

```
.
├── assets/
│   ├── agent_api_schema/
│   │   └── artifacts_schema.json        # OpenAPI schema defining the /uc2 Action Group endpoint
│   ├── agent_prompts/
│   │   └── agent_prompts.py             # Agent prompt templates
│   ├── data_query_data_source/
│   │   └── ec2_pricing/
│   │       └── ec2_pricing_762.csv      # EC2 pricing data (762 instance types)
│   ├── diagrams/
│   │   └── agent_architecture.png       # Architecture diagram
│   └── knowledgebase_data_source/
│       └── ec2_dg.zip                   # EC2 User Guide documents for RAG
│
├── code/
│   ├── lambdas/
│   │   ├── action-lambda/               # Text-to-SQL Lambda (Docker container)
│   │   │   ├── index.py                 # Handler — routes /uc2 and /uc1 API paths
│   │   │   ├── build_query_engine.py    # LlamaIndex SQLTableRetrieverQueryEngine setup
│   │   │   ├── connections.py           # AWS clients and BedrockConverse LLM factory
│   │   │   ├── prompt_templates.py      # SQL and response prompt templates + table schema
│   │   │   ├── dynamic_examples.csv     # Few-shot text-to-SQL examples
│   │   │   ├── requirements.txt         # Python deps (llama-index, PyAthena, SQLAlchemy)
│   │   │   └── Dockerfile               # Python 3.13 Lambda container image
│   │   │
│   │   ├── create-index-lambda/
│   │   │   └── index.py                 # Creates OpenSearch Serverless vector index (CFN custom resource)
│   │   │
│   │   ├── invoke-lambda/
│   │   │   └── index.py                 # Invokes Bedrock Agent, parses traces, returns answer + source
│   │   │
│   │   └── update-lambda/
│   │       ├── lambda_handler.py        # Orchestrates post-deploy setup (CFN custom resource)
│   │       ├── trigger_glue_crawler.py  # Starts and polls the Glue Crawler
│   │       ├── trigger_data_source_sync.py  # Syncs KB data source
│   │       ├── prepare_agent.py         # Prepares the Bedrock Agent
│   │       ├── create_agent_alias.py    # Creates the agent alias
│   │       └── connections.py           # Shared AWS client config
│   │
│   ├── layers/
│   │   ├── boto3_layer/                 # Shared boto3 Lambda layer
│   │   └── opensearch_layer/            # opensearch-py Lambda layer
│   │
│   └── streamlit-app/
│       ├── app.py                       # Streamlit UI — chat interface
│       ├── connections.py               # Lambda client config
│       ├── utils.py                     # UI helpers
│       ├── requirements.txt             # Streamlit app dependencies
│       └── Dockerfile                   # Python 3.13-slim container image
│
└── terraform/
    ├── main.tf                          # Provider and locals
    ├── bedrock.tf                       # Bedrock Agent, Knowledge Base, Action Group, data source
    ├── ecs.tf                           # VPC, ECS cluster/service, ALB, auto-scaling
    ├── glue.tf                          # Glue Crawler, database, security config
    ├── iam.tf                           # IAM roles and policies
    ├── kms.tf                           # KMS key
    ├── lambda.tf                        # All four Lambda functions + ECR for action Lambda
    ├── layers.tf                        # Lambda layers
    ├── opensearch.tf                    # OpenSearch Serverless collection and policies
    ├── s3.tf                            # S3 buckets and object uploads
    ├── variables.tf                     # Input variables
    ├── outputs.tf                       # Stack outputs (ALB URL, agent ID, etc.)
    └── backend.tf                       # Terraform state backend config
```

---

## Models

| Component | Model | Model ID |
|---|---|---|
| Bedrock Agent (orchestration) | Amazon Nova Pro | `amazon.nova-pro-v1:0` |
| Action Lambda (text-to-SQL) | Amazon Nova Pro | `amazon.nova-pro-v1:0` |
| Knowledge Base embeddings | Amazon Titan Embed Text v1 | `amazon.titan-embed-text-v1` |
| Few-shot retrieval embeddings | Amazon Titan Embed Text v1 | `amazon.titan-embed-text-v1` |

Nova models are available on-demand in `us-east-1` with no cross-region inference profile required. To switch models, update `bedrock_foundation_model` in `terraform/variables.tf` and the `MODELID_MAPPING` in `code/lambdas/action-lambda/connections.py`.

---

## Prerequisites

- Docker
- Terraform >= 1.5.0
- AWS CLI configured with credentials for your target account
- An active AWS account in `us-east-1` (default region)
- Amazon Bedrock model access enabled for:
  - **Amazon Nova Pro** (`amazon.nova-pro-v1:0`)
  - **Amazon Titan Embed Text v1** (`amazon.titan-embed-text-v1`)

---

## Deployment

### Deploy to AWS

Initialize Terraform and deploy:

```bash
cd terraform
terraform init
terraform apply
```

The first deployment takes approximately 30–45 minutes. It provisions all infrastructure, builds and pushes Docker images via GitHub Actions, and runs the post-deploy setup (Glue crawler, KB sync, agent alias creation).

After deployment, the Streamlit app URL is available in the Terraform outputs:

```bash
terraform output streamlit_alb_dns
```

### Local Development

Add a `.env` file to `code/streamlit-app/`:

```env
AWS_REGION=us-east-1
LAMBDA_FUNCTION_NAME=<invoke-lambda-function-name>
```

Run the Streamlit app locally:

```bash
cd code/streamlit-app
pip install -r requirements.txt
streamlit run app.py
```

### Cleanup

```bash
cd terraform
terraform destroy
```

Note: S3 buckets are set to `force_destroy = true` and will be deleted with the stack. The Bedrock Agent has `prevent_destroy = true` to avoid accidental deletion — remove that lifecycle block before running destroy if needed.

---

## Customize with Your Own Data

### Knowledge Base (Qualitative)

1. Place your documents in `assets/knowledgebase_data_source/`.
2. Update the S3 upload in `terraform/s3.tf` to point to your file.
3. Update `knowledgebase_instruction` in `terraform/variables.tf` to describe your dataset.

### Structured Data (Quantitative)

1. Place your CSV/Parquet data in `assets/data_query_data_source/<your-prefix>/`.
2. Update `athena_table_data_prefix` in `terraform/variables.tf` to match your path.
3. Update `code/lambdas/action-lambda/prompt_templates.py` with your table schema and column descriptions.
4. Update `code/lambdas/action-lambda/dynamic_examples.csv` with representative text-to-SQL examples for your dataset.
5. Update `assets/agent_api_schema/artifacts_schema.json` to reflect your action group's API.
6. Update `action_group_description` in `terraform/variables.tf` to describe when the agent should use the action group.
