locals {
  os_collection_name = "chatbot-oscollect-${local.account_id}"
}

# ── Encryption Policy ─────────────────────────────────────────────────────────

resource "aws_opensearchserverless_security_policy" "encryption" {
  name        = "chatbot-index-encryption-policy"
  type        = "encryption"
  description = "Encryption policy for Bedrock collection."
  policy = jsonencode({
    Rules = [{
      ResourceType = "collection"
      Resource     = ["collection/${local.os_collection_name}"]
    }]
    AWSOwnedKey = true
  })
}

# ── Network Policy ────────────────────────────────────────────────────────────

resource "aws_opensearchserverless_security_policy" "network" {
  name        = "chatbot-index-network-policy"
  type        = "network"
  description = "Network policy for Bedrock collection"
  policy = jsonencode([{
    Rules = [
      {
        ResourceType = "collection"
        Resource     = ["collection/${local.os_collection_name}"]
      },
      {
        ResourceType = "dashboard"
        Resource     = ["collection/${local.os_collection_name}"]
      }
    ]
    AllowFromPublic = true
  }])
}

# ── Data Access Policy ────────────────────────────────────────────────────────

resource "aws_opensearchserverless_access_policy" "data" {
  name        = "chatbot-index-data-policy"
  type        = "data"
  description = "Data policy for Bedrock collection."
  policy = jsonencode([{
    Description = "Access for cfn user"
    Rules = [
      {
        ResourceType = "index"
        Resource     = ["index/*/*"]
        Permission   = ["aoss:*"]
      },
      {
        ResourceType = "collection"
        Resource     = ["collection/${local.os_collection_name}"]
        Permission   = ["aoss:*"]
      }
    ]
    Principal = [
      aws_iam_role.bedrock_agent_role.arn,
      aws_iam_role.create_index_lambda_role.arn
    ]
  }])
}

# ── Collection ────────────────────────────────────────────────────────────────

resource "aws_opensearchserverless_collection" "chatbot" {
  name        = local.os_collection_name
  description = "ChatBot Agent Collection"
  type        = "VECTORSEARCH"

  depends_on = [
    aws_opensearchserverless_security_policy.encryption,
    aws_opensearchserverless_security_policy.network,
    aws_opensearchserverless_access_policy.data,
  ]
}
