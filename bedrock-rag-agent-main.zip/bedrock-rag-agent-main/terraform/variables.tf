variable "aws_region" {
  description = "AWS region to deploy resources"
  type        = string
  default     = "us-east-1"
}

variable "stack_name" {
  description = "Stack/project name prefix for all resources"
  type        = string
  default     = "chatbot-stack"
}

variable "bedrock_agent_name" {
  description = "Name of the Bedrock agent"
  type        = string
  default     = "ChatbotBedrockAgent"
}

variable "bedrock_agent_alias" {
  description = "Alias for the Bedrock agent"
  type        = string
  default     = "Chatbot_Agent"
}

variable "bedrock_foundation_model" {
  description = "Foundation model ID for the Bedrock agent"
  type        = string
  default     = "amazon.nova-pro-v1:0"
}

variable "agent_instruction" {
  description = "Instruction for the Bedrock agent"
  type        = string
  default     = "This is a test instruction. You were built by AWS to answer questions AWS related questions."
}

variable "knowledgebase_instruction" {
  description = "Instruction for the knowledge base association"
  type        = string
  default     = "Use this for returning descriptive answers and instructions directly from AWS Documentation. Use to answer qualitative/guidance questions such as 'how do I', general instructions and guidelines."
}

variable "action_group_description" {
  description = "Description for the agent action group"
  type        = string
  default     = "This is an action group for converting quantitative question, or part of a question, into a SQL query."
}

variable "lambda_log_level" {
  description = "Log level for Lambda functions"
  type        = string
  default     = "INFO"
}

variable "streamlit_log_level" {
  description = "Log level for Streamlit app"
  type        = string
  default     = "INFO"
}

variable "knowledgebase_destination_prefix" {
  description = "S3 prefix for knowledge base documents"
  type        = string
  default     = "knowledgebase_data_source"
}

variable "athena_data_destination_prefix" {
  description = "S3 prefix for Athena data"
  type        = string
  default     = "data_query_data_source"
}

variable "athena_table_data_prefix" {
  description = "S3 sub-prefix for Athena table data"
  type        = string
  default     = "ec2_pricing"
}

variable "agent_schema_destination_prefix" {
  description = "S3 prefix for agent API schema"
  type        = string
  default     = "agent_api_schema"
}

variable "fewshot_examples_path" {
  description = "Path to few-shot examples CSV inside the action Lambda"
  type        = string
  default     = "dynamic_examples.csv"
}

variable "streamlit_lambda_function_name" {
  description = "Name suffix for the invoke (Streamlit) Lambda"
  type        = string
  default     = "invokeAgentLambda"
}
