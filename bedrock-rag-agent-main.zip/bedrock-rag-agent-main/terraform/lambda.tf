# ── Action Lambda (container image) ──────────────────────────────────────────

resource "aws_ecr_repository" "action_lambda" {
  name                 = "${local.stack_name}-action-lambda"
  image_tag_mutability = "MUTABLE"
  force_delete         = true

  image_scanning_configuration { scan_on_push = true }
  encryption_configuration {
    encryption_type = "KMS"
    kms_key         = aws_kms_key.genai_key.arn
  }
}

# Build and push the action-lambda Docker image
# Images are built and pushed by the GitHub Actions workflow after ECR is created.

resource "aws_lambda_function" "action" {
  function_name = "${local.stack_name}-agent-action-lambda-${local.account_id}-${local.region}"
  description   = "Lambda code for GenAI Chatbot"
  role          = aws_iam_role.action_lambda_role.arn
  package_type  = "Image"
  image_uri     = "${aws_ecr_repository.action_lambda.repository_url}:latest"
  architectures = ["x86_64"]
  timeout       = 900
  memory_size   = 3008

  ephemeral_storage { size = 4096 }

  kms_key_arn = aws_kms_key.genai_key.arn

  environment {
    variables = {
      ATHENA_BUCKET_NAME    = aws_s3_bucket.athena.bucket
      TEXT2SQL_DATABASE     = aws_glue_catalog_database.text2sql.name
      LOG_LEVEL             = var.lambda_log_level
      FEWSHOT_EXAMPLES_PATH = var.fewshot_examples_path
    }
  }

  depends_on = [aws_ecr_repository.action_lambda]
}

resource "aws_lambda_permission" "bedrock_invoke_action" {
  statement_id   = "BedrockLambdaInvokePermission"
  action         = "lambda:InvokeFunction"
  function_name  = aws_lambda_function.action.function_name
  principal      = "bedrock.amazonaws.com"
  source_account = local.account_id
  source_arn     = "arn:aws:bedrock:${local.region}:${local.account_id}:agent/*"
}

# ── Create-Index Lambda ───────────────────────────────────────────────────────

resource "aws_lambda_function" "create_index" {
  function_name = "${local.stack_name}-create-index-lambda-${local.account_id}-${local.region}"
  role          = aws_iam_role.create_index_lambda_role.arn
  runtime       = "python3.13"
  handler       = "index.lambda_handler"
  timeout       = 900
  architectures = ["arm64"]

  filename         = data.archive_file.create_index.output_path
  source_code_hash = data.archive_file.create_index.output_base64sha256

  tracing_config { mode = "Active" }

  environment {
    variables = {
      REGION_NAME       = local.region
      COLLECTION_HOST   = aws_opensearchserverless_collection.chatbot.collection_endpoint
      VECTOR_INDEX_NAME = "bedrock-knowledgebase-index"
      VECTOR_FIELD_NAME = "bedrock-knowledge-base-default-vector"
    }
  }

  layers = [aws_lambda_layer_version.opensearch.arn]
}



data "archive_file" "create_index" {
  type        = "zip"
  source_dir  = "${path.module}/../code/lambdas/create-index-lambda"
  output_path = "${path.module}/.build/create-index-lambda.zip"
}

# ── Invoke Lambda ─────────────────────────────────────────────────────────────

resource "aws_lambda_function" "invoke" {
  function_name = "${local.stack_name}-${var.streamlit_lambda_function_name}-${local.account_id}-${local.region}"
  role          = aws_iam_role.invoke_lambda_role.arn
  runtime       = "python3.13"
  handler       = "index.lambda_handler"
  timeout       = 900
  architectures = ["arm64"]

  filename         = data.archive_file.invoke.output_path
  source_code_hash = data.archive_file.invoke.output_base64sha256

  tracing_config { mode = "Active" }

  environment {
    variables = {
      AGENT_ID    = aws_bedrockagent_agent.chatbot.agent_id
      REGION_NAME = local.region
    }
  }

  layers = [aws_lambda_layer_version.boto3.arn]
}

data "archive_file" "invoke" {
  type        = "zip"
  source_dir  = "${path.module}/../code/lambdas/invoke-lambda"
  output_path = "${path.module}/.build/invoke-lambda.zip"
}

# ── Update Lambda ─────────────────────────────────────────────────────────────

resource "aws_lambda_function" "update" {
  function_name = "${local.stack_name}-update-lambda-${local.account_id}-${local.region}"
  description   = "Lambda code to trigger crawler, create bedrock agent alias, knowledgebase data sync"
  role          = aws_iam_role.update_lambda_role.arn
  runtime       = "python3.13"
  handler       = "lambda_handler.lambda_handler"
  timeout       = 900
  memory_size   = 1024
  architectures = ["arm64"]

  filename         = data.archive_file.update.output_path
  source_code_hash = data.archive_file.update.output_base64sha256

  environment {
    variables = {
      GLUE_CRAWLER_NAME               = aws_glue_crawler.text2sql.name
      KNOWLEDGEBASE_ID                = aws_bedrockagent_knowledge_base.chatbot.id
      KNOWLEDGEBASE_DATASOURCE_ID     = aws_bedrockagent_data_source.chatbot.data_source_id
      BEDROCK_AGENT_ID                = aws_bedrockagent_agent.chatbot.agent_id
      BEDROCK_AGENT_NAME              = var.bedrock_agent_name
      BEDROCK_AGENT_ALIAS             = var.bedrock_agent_alias
      BEDROCK_AGENT_RESOURCE_ROLE_ARN = aws_iam_role.bedrock_agent_role.arn
      LOG_LEVEL                       = "info"
    }
  }

  layers = [aws_lambda_layer_version.boto3.arn]
}

data "archive_file" "update" {
  type        = "zip"
  source_dir  = "${path.module}/../code/lambdas/update-lambda"
  output_path = "${path.module}/.build/update-lambda.zip"
}
