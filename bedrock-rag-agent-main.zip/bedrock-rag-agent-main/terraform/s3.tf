# ── Agent Assets Bucket ──────────────────────────────────────────────────────

resource "aws_s3_bucket" "agent_assets" {
  bucket        = "${local.stack_name}-agent-assets-bucket-${local.account_id}"
  force_destroy = true

  tags = { Name = "${local.stack_name}-agent-assets" }
}

resource "aws_s3_bucket_versioning" "agent_assets" {
  bucket = aws_s3_bucket.agent_assets.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "agent_assets" {
  bucket = aws_s3_bucket.agent_assets.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.genai_key.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "agent_assets" {
  bucket                  = aws_s3_bucket.agent_assets.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "agent_assets_ssl" {
  bucket = aws_s3_bucket.agent_assets.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "DenyNonSSL"
      Effect    = "Deny"
      Principal = "*"
      Action    = "s3:*"
      Resource = [
        aws_s3_bucket.agent_assets.arn,
        "${aws_s3_bucket.agent_assets.arn}/*"
      ]
      Condition = { Bool = { "aws:SecureTransport" = "false" } }
    }]
  })
}

# Upload knowledge base document
resource "aws_s3_object" "knowledgebase_doc" {
  bucket = aws_s3_bucket.agent_assets.id
  key    = "${var.knowledgebase_destination_prefix}/ec2_dg.zip"
  source = "${path.module}/../assets/knowledgebase_data_source/ec2_dg.zip"
  etag   = filemd5("${path.module}/../assets/knowledgebase_data_source/ec2_dg.zip")
}

# Upload agent API schema
resource "aws_s3_object" "agent_schema" {
  bucket = aws_s3_bucket.agent_assets.id
  key    = "${var.agent_schema_destination_prefix}/artifacts_schema.json"
  source = "${path.module}/../assets/agent_api_schema/artifacts_schema.json"
  etag   = filemd5("${path.module}/../assets/agent_api_schema/artifacts_schema.json")
}

# ── Athena Bucket ─────────────────────────────────────────────────────────────

resource "aws_s3_bucket" "athena" {
  bucket        = "${local.stack_name}-athena-bucket-${local.account_id}"
  force_destroy = true

  tags = { Name = "${local.stack_name}-athena" }
}

resource "aws_s3_bucket_versioning" "athena" {
  bucket = aws_s3_bucket.athena.id
  versioning_configuration { status = "Enabled" }
}

resource "aws_s3_bucket_server_side_encryption_configuration" "athena" {
  bucket = aws_s3_bucket.athena.id
  rule {
    apply_server_side_encryption_by_default {
      sse_algorithm     = "aws:kms"
      kms_master_key_id = aws_kms_key.genai_key.arn
    }
  }
}

resource "aws_s3_bucket_public_access_block" "athena" {
  bucket                  = aws_s3_bucket.athena.id
  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true
}

resource "aws_s3_bucket_policy" "athena_ssl" {
  bucket = aws_s3_bucket.athena.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Sid       = "DenyNonSSL"
      Effect    = "Deny"
      Principal = "*"
      Action    = "s3:*"
      Resource = [
        aws_s3_bucket.athena.arn,
        "${aws_s3_bucket.athena.arn}/*"
      ]
      Condition = { Bool = { "aws:SecureTransport" = "false" } }
    }]
  })
}

# Upload EC2 pricing CSV
resource "aws_s3_object" "ec2_pricing" {
  bucket = aws_s3_bucket.athena.id
  key    = "${var.athena_data_destination_prefix}/${var.athena_table_data_prefix}/ec2_pricing_762.csv"
  source = "${path.module}/../assets/data_query_data_source/ec2_pricing/ec2_pricing_762.csv"
  etag   = filemd5("${path.module}/../assets/data_query_data_source/ec2_pricing/ec2_pricing_762.csv")
}
