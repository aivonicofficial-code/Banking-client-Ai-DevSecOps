# ── Glue IAM Role ─────────────────────────────────────────────────────────────

resource "aws_iam_role" "glue_role" {
  name = "${local.stack_name}-glue-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "glue.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "glue_service" {
  role       = aws_iam_role.glue_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}

resource "aws_iam_role_policy" "glue_s3_access" {
  name = "glue-s3-kms-access"
  role = aws_iam_role.glue_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["s3:GetObject", "s3:ListBucket"]
        Resource = [
          aws_s3_bucket.athena.arn,
          "${aws_s3_bucket.athena.arn}/*"
        ]
      },
      {
        Effect   = "Allow"
        Action   = ["kms:Encrypt", "kms:Decrypt", "kms:ReEncrypt*", "kms:GenerateDataKey*", "kms:DescribeKey"]
        Resource = aws_kms_key.genai_key.arn
      },
      {
        Effect   = "Allow"
        Action   = ["logs:AssociateKmsKey"]
        Resource = "*"
      }
    ]
  })
}

# ── Glue Security Configuration ───────────────────────────────────────────────

resource "aws_glue_security_configuration" "chatbot" {
  name = "${local.stack_name}-security-config"
  encryption_configuration {
    cloudwatch_encryption {
      cloudwatch_encryption_mode = "SSE-KMS"
      kms_key_arn                = aws_kms_key.genai_key.arn
    }
    s3_encryption {
      s3_encryption_mode = "SSE-KMS"
      kms_key_arn        = aws_kms_key.genai_key.arn
    }
    job_bookmarks_encryption {
      job_bookmarks_encryption_mode = "DISABLED"
    }
  }
}

# ── Glue Database ─────────────────────────────────────────────────────────────

resource "aws_glue_catalog_database" "text2sql" {
  name = "${local.stack_name}-text2sql-db"
}

# ── Glue Crawler ──────────────────────────────────────────────────────────────

resource "aws_glue_crawler" "text2sql" {
  name                   = "${local.stack_name}-text2sql-table-crawler"
  description            = "Crawler job for EC2 pricing"
  role                   = aws_iam_role.glue_role.arn
  database_name          = aws_glue_catalog_database.text2sql.name
  security_configuration = aws_glue_security_configuration.chatbot.name

  s3_target {
    path = "s3://${aws_s3_bucket.athena.bucket}/${var.athena_data_destination_prefix}/${var.athena_table_data_prefix}"
  }
}
