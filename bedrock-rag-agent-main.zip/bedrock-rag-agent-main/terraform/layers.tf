# ── boto3 Layer ───────────────────────────────────────────────────────────────

data "archive_file" "boto3_layer" {
  type        = "zip"
  source_dir  = "${path.module}/../code/layers/boto3_layer"
  output_path = "${path.module}/.build/boto3_layer.zip"
  excludes    = ["requirements.txt"]
}

resource "aws_lambda_layer_version" "boto3" {
  layer_name               = "boto3_layer"
  filename                 = data.archive_file.boto3_layer.output_path
  source_code_hash         = data.archive_file.boto3_layer.output_base64sha256
  compatible_runtimes      = ["python3.13"]
  compatible_architectures = ["arm64"]
  description              = "A layer with new version of boto3"
}

# ── opensearch Layer ──────────────────────────────────────────────────────────

data "archive_file" "opensearch_layer" {
  type        = "zip"
  source_dir  = "${path.module}/../code/layers/opensearch_layer"
  output_path = "${path.module}/.build/opensearch_layer.zip"
  excludes    = ["requirements.txt"]
}

resource "aws_lambda_layer_version" "opensearch" {
  layer_name               = "opensearch_layer"
  filename                 = data.archive_file.opensearch_layer.output_path
  source_code_hash         = data.archive_file.opensearch_layer.output_base64sha256
  compatible_runtimes      = ["python3.13"]
  compatible_architectures = ["arm64"]
  description              = "OpenSearch client layer"
}
