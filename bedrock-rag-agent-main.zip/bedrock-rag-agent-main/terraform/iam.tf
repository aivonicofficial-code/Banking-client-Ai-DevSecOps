# ── Bedrock Agent Execution Role ──────────────────────────────────────────────

resource "aws_iam_role" "bedrock_agent_role" {
  # Must follow the naming convention AmazonBedrockExecutionRoleForAgents_*
  name = "AmazonBedrockExecutionRoleForAgents_chatbot"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "bedrock.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "bedrock_agent_policy" {
  name = "bedrock-agent-policy"
  role = aws_iam_role.bedrock_agent_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "bedrock:InvokeModel",
          "bedrock:InvokeModelWithResponseStream",
          "bedrock:GetFoundationModel"
        ]
        Resource = [
          "arn:aws:bedrock:*::foundation-model/amazon.nova-pro-v1:0",
          "arn:aws:bedrock:*::foundation-model/amazon.nova-lite-v1:0",
          "arn:aws:bedrock:*::foundation-model/amazon.nova-micro-v1:0",
          "arn:aws:bedrock:${local.region}::foundation-model/amazon.titan-embed-text-v1"
        ]
      },
      {
        Effect = "Allow"
        Action = ["s3:GetObject", "s3:ListBucket"]
        Resource = [
          aws_s3_bucket.agent_assets.arn,
          "${aws_s3_bucket.agent_assets.arn}/*"
        ]
        Condition = {
          StringEquals = { "aws:ResourceAccount" = local.account_id }
        }
      },
      {
        Effect = "Allow"
        Action = ["bedrock:Retrieve", "bedrock:RetrieveAndGenerate"]
        Resource = [
          "arn:aws:bedrock:${local.region}:${local.account_id}:knowledge-base/*"
        ]
        Condition = {
          StringEquals = { "aws:ResourceAccount" = local.account_id }
        }
      },
      {
        Effect   = "Allow"
        Action   = ["aoss:APIAccessAll"]
        Resource = ["arn:aws:aoss:${local.region}:${local.account_id}:collection/${aws_opensearchserverless_collection.chatbot.id}"]
      }
    ]
  })
}

# ── Action Lambda Role ────────────────────────────────────────────────────────

resource "aws_iam_role" "action_lambda_role" {
  name = "${local.stack_name}-action-lambda-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "action_lambda_basic" {
  role       = aws_iam_role.action_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy_attachment" "action_lambda_athena" {
  role       = aws_iam_role.action_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonAthenaFullAccess"
}

resource "aws_iam_role_policy_attachment" "action_lambda_bedrock" {
  role       = aws_iam_role.action_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonBedrockFullAccess"
}

resource "aws_iam_role_policy" "action_lambda_s3" {
  name = "action-lambda-s3-access"
  role = aws_iam_role.action_lambda_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = ["s3:GetObject", "s3:PutObject", "s3:ListBucket", "s3:DeleteObject"]
      Resource = [
        aws_s3_bucket.agent_assets.arn,
        "${aws_s3_bucket.agent_assets.arn}/*",
        aws_s3_bucket.athena.arn,
        "${aws_s3_bucket.athena.arn}/*"
      ]
    }]
  })
}

# ── Create-Index Lambda Role ──────────────────────────────────────────────────

resource "aws_iam_role" "create_index_lambda_role" {
  name = "${local.stack_name}-create-index-lambda-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "create_index_lambda_basic" {
  role       = aws_iam_role.create_index_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "create_index_lambda_aoss" {
  name = "create-index-aoss-access"
  role = aws_iam_role.create_index_lambda_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["aoss:APIAccessAll"]
      Resource = ["arn:aws:aoss:${local.region}:${local.account_id}:collection/${aws_opensearchserverless_collection.chatbot.id}"]
    }]
  })
}

# ── Invoke Lambda Role ────────────────────────────────────────────────────────

resource "aws_iam_role" "invoke_lambda_role" {
  name = "${local.stack_name}-invoke-lambda-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "invoke_lambda_basic" {
  role       = aws_iam_role.invoke_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy" "invoke_lambda_bedrock" {
  name = "invoke-lambda-bedrock-access"
  role = aws_iam_role.invoke_lambda_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = ["bedrock:ListAgents", "bedrock:ListAgentAliases", "bedrock:InvokeAgent"]
        Resource = [
          "arn:aws:bedrock:${local.region}:${local.account_id}:agent/${aws_bedrockagent_agent.chatbot.agent_id}",
          "arn:aws:bedrock:${local.region}:${local.account_id}:agent-alias/${aws_bedrockagent_agent.chatbot.agent_id}/*"
        ]
      },
      {
        Effect = "Allow"
        Action = ["s3:GetObject", "s3:ListBucket"]
        Resource = [
          aws_s3_bucket.agent_assets.arn,
          "${aws_s3_bucket.agent_assets.arn}/*"
        ]
      }
    ]
  })
}

# ── Update Lambda Role ────────────────────────────────────────────────────────

resource "aws_iam_role" "update_lambda_role" {
  name = "${local.stack_name}-update-lambda-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "lambda.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "update_lambda_basic" {
  role       = aws_iam_role.update_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSLambdaBasicExecutionRole"
}

resource "aws_iam_role_policy_attachment" "update_lambda_glue_service" {
  role       = aws_iam_role.update_lambda_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AWSGlueServiceRole"
}

resource "aws_iam_role_policy" "update_lambda_glue" {
  name = "update-lambda-glue-access"
  role = aws_iam_role.update_lambda_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["glue:GetCrawler", "glue:StartCrawler"]
        Resource = ["arn:aws:glue:${local.region}::crawler/${aws_glue_crawler.text2sql.name}"]
      },
      {
        Effect = "Allow"
        Action = [
          "bedrock:StartIngestionJob", "bedrock:UpdateAgentKnowledgeBase",
          "bedrock:GetAgentAlias", "bedrock:UpdateKnowledgeBase",
          "bedrock:UpdateAgent", "bedrock:GetIngestionJob",
          "bedrock:CreateAgentAlias", "bedrock:UpdateAgentAlias",
          "bedrock:GetAgent", "bedrock:PrepareAgent",
          "bedrock:DeleteAgentAlias", "bedrock:DeleteAgent",
          "bedrock:ListAgentAliases"
        ]
        Resource = [
          "arn:aws:bedrock:${local.region}:${local.account_id}:agent/*",
          "arn:aws:bedrock:${local.region}:${local.account_id}:agent-alias/*",
          "arn:aws:bedrock:${local.region}:${local.account_id}:knowledge-base/*"
        ]
      }
    ]
  })
}

# ── ECS Task Role ─────────────────────────────────────────────────────────────

resource "aws_iam_role" "ecs_task_role" {
  name = "${local.stack_name}-ecs-task-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy" "ecs_task_invoke_lambda" {
  name = "ecs-invoke-lambda"
  role = aws_iam_role.ecs_task_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["lambda:InvokeFunction"]
      Resource = aws_lambda_function.invoke.arn
    }]
  })
}

resource "aws_iam_role" "ecs_task_execution_role" {
  name = "${local.stack_name}-ecs-task-execution-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ecs-tasks.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ecs_task_execution" {
  role       = aws_iam_role.ecs_task_execution_role.name
  policy_arn = "arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy"
}
