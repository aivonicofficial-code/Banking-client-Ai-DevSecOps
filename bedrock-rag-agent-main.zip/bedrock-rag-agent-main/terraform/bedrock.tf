# ── Knowledge Base ────────────────────────────────────────────────────────────

resource "aws_bedrockagent_knowledge_base" "chatbot" {
  name        = "BedrockKnowledgeBase-${local.stack_name}"
  description = "Use this for returning descriptive answers and instructions directly from AWS EC2 Documentation. Use to answer qualitative/guidance questions such as 'how do I', general instructions and guidelines."
  role_arn    = aws_iam_role.bedrock_agent_role.arn

  knowledge_base_configuration {
    type = "VECTOR"
    vector_knowledge_base_configuration {
      embedding_model_arn = "arn:aws:bedrock:${local.region}::foundation-model/amazon.titan-embed-text-v1"
    }
  }

  storage_configuration {
    type = "OPENSEARCH_SERVERLESS"
    opensearch_serverless_configuration {
      collection_arn    = aws_opensearchserverless_collection.chatbot.arn
      vector_index_name = "bedrock-knowledgebase-index"
      field_mapping {
        metadata_field = "AMAZON_BEDROCK_METADATA"
        text_field     = "AMAZON_BEDROCK_TEXT_CHUNK"
        vector_field   = "bedrock-knowledge-base-default-vector"
      }
    }
  }

  depends_on = [
    aws_opensearchserverless_collection.chatbot,
  ]
}

# ── Knowledge Base Data Source ────────────────────────────────────────────────

resource "aws_bedrockagent_data_source" "chatbot" {
  knowledge_base_id = aws_bedrockagent_knowledge_base.chatbot.id
  name              = "BedrockKnowledgeBaseSource-${local.stack_name}"

  data_source_configuration {
    type = "S3"
    s3_configuration {
      bucket_arn         = aws_s3_bucket.agent_assets.arn
      inclusion_prefixes = ["${var.knowledgebase_destination_prefix}/"]
    }
  }
}

# ── Bedrock Agent ─────────────────────────────────────────────────────────────

resource "aws_bedrockagent_agent" "chatbot" {
  agent_name                  = var.bedrock_agent_name
  description                 = "Bedrock Chatbot Agent"
  instruction                 = var.agent_instruction
  foundation_model            = var.bedrock_foundation_model
  agent_resource_role_arn     = aws_iam_role.bedrock_agent_role.arn
  idle_session_ttl_in_seconds = 3600
  prepare_agent               = true

  depends_on = [aws_bedrockagent_knowledge_base.chatbot]
}

# ── Agent Action Group ────────────────────────────────────────────────────────

resource "aws_bedrockagent_agent_action_group" "chatbot" {
  agent_id            = aws_bedrockagent_agent.chatbot.agent_id
  agent_version       = "DRAFT"
  action_group_name   = "ChatBotBedrockAgentActionGroup"
  description         = var.action_group_description
  action_group_state  = "ENABLED"

  action_group_executor {
    lambda = aws_lambda_function.action.arn
  }

  api_schema {
    s3 {
      s3_bucket_name = aws_s3_bucket.agent_assets.bucket
      s3_object_key  = "${var.agent_schema_destination_prefix}/artifacts_schema.json"
    }
  }
}

# ── Agent Knowledge Base Association ─────────────────────────────────────────

resource "aws_bedrockagent_agent_knowledge_base_association" "chatbot" {
  agent_id             = aws_bedrockagent_agent.chatbot.agent_id
  knowledge_base_id    = aws_bedrockagent_knowledge_base.chatbot.id
  description          = var.knowledgebase_instruction
  knowledge_base_state = "ENABLED"
}

# ── Agent Alias (created by update Lambda via custom resource) ────────────────
# The update Lambda handles alias creation/update at deploy time.
# If you prefer Terraform-managed alias, uncomment below:
#
# resource "aws_bedrockagent_agent_alias" "chatbot" {
#   agent_id         = aws_bedrockagent_agent.chatbot.agent_id
#   agent_alias_name = var.bedrock_agent_alias
# }
