output "assets_bucket_name" {
  description = "S3 bucket for agent assets"
  value       = aws_s3_bucket.agent_assets.bucket
}

output "athena_bucket_name" {
  description = "S3 bucket for Athena data"
  value       = aws_s3_bucket.athena.bucket
}

output "bedrock_agent_id" {
  description = "Bedrock Agent ID"
  value       = aws_bedrockagent_agent.chatbot.agent_id
}

output "knowledge_base_id" {
  description = "Bedrock Knowledge Base ID"
  value       = aws_bedrockagent_knowledge_base.chatbot.id
}

output "opensearch_collection_endpoint" {
  description = "OpenSearch Serverless collection endpoint"
  value       = aws_opensearchserverless_collection.chatbot.collection_endpoint
}

output "streamlit_invoke_lambda_function" {
  description = "Invoke Lambda function name for Streamlit"
  value       = aws_lambda_function.invoke.function_name
}

output "streamlit_alb_dns" {
  description = "DNS name of the Application Load Balancer (Streamlit app URL)"
  value       = "http://${aws_lb.chatbot.dns_name}"
}

output "ecs_cluster_name" {
  description = "ECS cluster name"
  value       = aws_ecs_cluster.chatbot.name
}

output "ecs_service_name" {
  description = "ECS service name"
  value       = aws_ecs_service.streamlit.name
}
