import os
import boto3
from llama_index.llms.bedrock_converse import BedrockConverse


class Connections:
    region_name = os.environ["AWS_REGION"]
    athena_bucket_name = os.environ["ATHENA_BUCKET_NAME"]
    text2sql_database = os.environ["TEXT2SQL_DATABASE"]
    log_level = os.environ["LOG_LEVEL"]
    fewshot_examples_path = os.environ["FEWSHOT_EXAMPLES_PATH"]
    s3_resource = boto3.resource("s3", region_name=region_name)
    bedrock_client = boto3.client("bedrock-runtime", region_name=region_name)

    # Amazon Nova models — native Amazon models, available on-demand (no cross-region profile needed)
    MODELID_MAPPING = {
        "NovaPro": "amazon.nova-pro-v1:0",
        "NovaLite": "amazon.nova-lite-v1:0",
        "NovaMicro": "amazon.nova-micro-v1:0",
        "Titan": "amazon.titan-tg1-large",
    }

    @staticmethod
    def get_bedrock_llm(model_name="NovaPro", max_tokens=256):
        model_id = Connections.MODELID_MAPPING.get(model_name)
        if not model_id:
            raise ValueError(f"Unknown model: {model_name}. Available: {list(Connections.MODELID_MAPPING.keys())}")

        llm = BedrockConverse(
            model=model_id,
            region_name=Connections.region_name,
            max_tokens=max_tokens,
            temperature=0,
        )
        return llm
