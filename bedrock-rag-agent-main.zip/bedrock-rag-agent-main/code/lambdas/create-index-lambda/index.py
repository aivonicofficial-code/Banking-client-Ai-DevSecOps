from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth
import os
import boto3
import json
import logging
import time

try:
    import cfnresponse
    HAS_CFN = True
except ImportError:
    HAS_CFN = False

HOST = os.environ.get("COLLECTION_HOST")
VECTOR_INDEX_NAME = os.environ.get("VECTOR_INDEX_NAME")
VECTOR_FIELD_NAME = os.environ.get("VECTOR_FIELD_NAME")
REGION_NAME = os.environ.get("REGION_NAME")
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def send_cfn_response(event, context, status, response):
    """Send response to CloudFormation only when invoked as a custom resource."""
    if HAS_CFN and event.get("ResponseURL") and "localhost" not in event.get("ResponseURL", ""):
        cfnresponse.send(event, context, status, response)


def lambda_handler(event, context):
    """Lambda handler to create OpenSearch Index."""
    logger.info(f"Event: {json.dumps(event)}")

    request_type = event.get("RequestType", "Create")
    status = cfnresponse.SUCCESS if HAS_CFN else "SUCCESS"
    response = {}

    try:
        session = boto3.Session()
        creds = session.get_credentials()

        caller = session.client("sts").get_caller_identity()
        logger.info(f"Caller ARN: {caller['Arn']}")
        logger.info(f"HOST: {HOST}")

        host = HOST.split("//")[1]
        auth = AWSV4SignerAuth(creds, REGION_NAME, "aoss")

        client = OpenSearch(
            hosts=[{"host": host, "port": 443}],
            http_auth=auth,
            use_ssl=True,
            verify_certs=True,
            connection_class=RequestsHttpConnection,
            pool_maxsize=20,
        )

        if request_type == "Create":
            logger.info(f"Creating index: {VECTOR_INDEX_NAME}")

            index_body = {
                "settings": {
                    "index.knn": True,
                    "index.knn.algo_param.ef_search": 512,
                },
                "mappings": {
                    "properties": {
                        VECTOR_FIELD_NAME: {
                            "type": "knn_vector",
                            "dimension": 1536,
                            "method": {
                                "space_type": "innerproduct",
                                "engine": "faiss",
                                "name": "hnsw",
                                "parameters": {"m": 16, "ef_construction": 512},
                            },
                        },
                        "AMAZON_BEDROCK_METADATA": {"type": "text", "index": False},
                        "AMAZON_BEDROCK_TEXT_CHUNK": {"type": "text"},
                        "id": {"type": "text"},
                    }
                },
            }

            resp = client.indices.create(index=VECTOR_INDEX_NAME, body=index_body)
            logger.info(f"Index creation response: {resp}")

            logger.info("Waiting 60s for index to be ready...")
            time.sleep(60)  # nosem: arbitrary-sleep

            response = {"message": "Index created successfully"}

        elif request_type == "Delete":
            logger.info(f"Deleting index: {VECTOR_INDEX_NAME}")
            resp = client.indices.delete(index=VECTOR_INDEX_NAME)
            logger.info(f"Delete response: {resp}")
            response = {"message": "Index deleted successfully"}

        else:
            logger.info("No action required.")
            response = {"message": "No action taken"}

    except Exception as e:
        logger.error(f"Exception: {e}", exc_info=True)
        if HAS_CFN:
            status = cfnresponse.FAILED
        send_cfn_response(event, context, status, {"Error": str(e)})
        raise

    send_cfn_response(event, context, status, response)

    return {
        "statusCode": 200,
        "body": json.dumps(response),
    }
